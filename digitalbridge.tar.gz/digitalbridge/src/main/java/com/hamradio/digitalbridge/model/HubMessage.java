package com.hamradio.digitalbridge.model;

import com.google.gson.JsonObject;

/**
 * Generic wrapper for messages exchanged with the hub server via WebSocket.
 * The "type" field discriminates the payload; other fields are type-specific.
 */
public class HubMessage {

    /** Message type discriminator, e.g. "WSJTX_DECODE", "RIG_STATUS" */
    private String type;

    /**
     * Raw JSON payload.  Kept as JsonObject so that callers can extract
     * arbitrary fields without forcing a rigid schema on every message type.
     */
    private transient JsonObject raw;

    // ── Static factory helpers ─────────────────────────────────────────────────

    /** Build a plain type-only message (e.g. APP_CONNECTED skeleton). */
    public static HubMessage of(String type) {
        HubMessage m = new HubMessage();
        m.type = type;
        return m;
    }

    // ── Getters / Setters ─────────────────────────────────────────────────────

    public String getType() { return type; }
    public void setType(String type) { this.type = type; }

    public JsonObject getRaw() { return raw; }
    public void setRaw(JsonObject raw) { this.raw = raw; }

    /** Convenience: pull a String field from raw JSON, returns null if absent. */
    public String getString(String field) {
        if (raw == null || !raw.has(field)) return null;
        return raw.get(field).isJsonNull() ? null : raw.get(field).getAsString();
    }

    /** Convenience: pull a long field from raw JSON, returns defaultVal if absent. */
    public long getLong(String field, long defaultVal) {
        if (raw == null || !raw.has(field)) return defaultVal;
        try { return raw.get(field).getAsLong(); } catch (Exception e) { return defaultVal; }
    }

    /** Convenience: pull a double field from raw JSON. */
    public double getDouble(String field, double defaultVal) {
        if (raw == null || !raw.has(field)) return defaultVal;
        try { return raw.get(field).getAsDouble(); } catch (Exception e) { return defaultVal; }
    }

    @Override
    public String toString() {
        return "HubMessage{type='" + type + "'}";
    }
}
