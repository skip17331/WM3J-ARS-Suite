package com.hamradio.digitalbridge.model;

import java.time.Instant;

/**
 * Represents a decoded signal from WSJT-X (UDP message type 2).
 * Populated by WsjtxProtocolDecoder and enriched by SpotEnricher.
 */
public class WsjtxDecode {

    // ── Raw WSJT-X fields ──────────────────────────────────────────────────────

    /** UTC time of the decode (start of transmission period) */
    private Instant timestamp;

    /** Signal-to-noise ratio in dB */
    private int snr;

    /** Delta time in seconds (signal timing vs period start) */
    private double deltaTime;

    /** Audio frequency offset in Hz */
    private int deltaFrequency;

    /** Decoded message text, e.g. "CQ W3ABC FM19" */
    private String message;

    /** Whether this decode came from a low-confidence (shallow) decode */
    private boolean lowConfidence;

    /** Whether this decode came during an off-period */
    private boolean offAir;

    /** Mode string, e.g. "FT8", "JT65" */
    private String mode;

    /** RF frequency in Hz (from last WSJT-X status) */
    private long frequency;

    /** Ham band string derived from frequency, e.g. "20m" */
    private String band;

    // ── Parsed callsign ────────────────────────────────────────────────────────

    /** DX callsign extracted from message text by CallsignParser */
    private String callsign;

    // ── Enrichment fields (from SpotEnricher / hub) ────────────────────────────

    /** Country name resolved from callsign prefix */
    private String country;

    /** ITU/CQ continent code, e.g. "EU", "NA" */
    private String continent;

    /** DXCC entity number */
    private int dxcc;

    /** Approximate latitude of the DX station */
    private double lat;

    /** Approximate longitude of the DX station */
    private double lon;

    /** True bearing in degrees from our station to the DX station */
    private double bearing;

    /** Great-circle distance to DX station in kilometres */
    private double distanceKm;

    /** Great-circle distance to DX station in statute miles */
    private double distanceMi;

    /** Local time at the DX station location, e.g. "19:45" */
    private String localTimeAtSpot;

    /** Worked status: "worked", "needed", or "unknown" */
    private String workedStatus;

    // ── Constructors ──────────────────────────────────────────────────────────

    public WsjtxDecode() {
        this.workedStatus = "unknown";
    }

    // ── Getters and Setters ───────────────────────────────────────────────────

    public Instant getTimestamp() { return timestamp; }
    public void setTimestamp(Instant timestamp) { this.timestamp = timestamp; }

    public int getSnr() { return snr; }
    public void setSnr(int snr) { this.snr = snr; }

    public double getDeltaTime() { return deltaTime; }
    public void setDeltaTime(double deltaTime) { this.deltaTime = deltaTime; }

    public int getDeltaFrequency() { return deltaFrequency; }
    public void setDeltaFrequency(int deltaFrequency) { this.deltaFrequency = deltaFrequency; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    public boolean isLowConfidence() { return lowConfidence; }
    public void setLowConfidence(boolean lowConfidence) { this.lowConfidence = lowConfidence; }

    public boolean isOffAir() { return offAir; }
    public void setOffAir(boolean offAir) { this.offAir = offAir; }

    public String getMode() { return mode; }
    public void setMode(String mode) { this.mode = mode; }

    public long getFrequency() { return frequency; }
    public void setFrequency(long frequency) { this.frequency = frequency; }

    public String getBand() { return band; }
    public void setBand(String band) { this.band = band; }

    public String getCallsign() { return callsign; }
    public void setCallsign(String callsign) { this.callsign = callsign; }

    public String getCountry() { return country; }
    public void setCountry(String country) { this.country = country; }

    public String getContinent() { return continent; }
    public void setContinent(String continent) { this.continent = continent; }

    public int getDxcc() { return dxcc; }
    public void setDxcc(int dxcc) { this.dxcc = dxcc; }

    public double getLat() { return lat; }
    public void setLat(double lat) { this.lat = lat; }

    public double getLon() { return lon; }
    public void setLon(double lon) { this.lon = lon; }

    public double getBearing() { return bearing; }
    public void setBearing(double bearing) { this.bearing = bearing; }

    public double getDistanceKm() { return distanceKm; }
    public void setDistanceKm(double distanceKm) { this.distanceKm = distanceKm; }

    public double getDistanceMi() { return distanceMi; }
    public void setDistanceMi(double distanceMi) { this.distanceMi = distanceMi; }

    public String getLocalTimeAtSpot() { return localTimeAtSpot; }
    public void setLocalTimeAtSpot(String localTimeAtSpot) { this.localTimeAtSpot = localTimeAtSpot; }

    public String getWorkedStatus() { return workedStatus; }
    public void setWorkedStatus(String workedStatus) { this.workedStatus = workedStatus; }

    /** Returns true if the message text starts with "CQ" */
    public boolean isCqCall() {
        return message != null && message.trim().toUpperCase().startsWith("CQ");
    }

    @Override
    public String toString() {
        return "WsjtxDecode{" +
               "callsign='" + callsign + '\'' +
               ", snr=" + snr +
               ", freq=" + deltaFrequency +
               ", message='" + message + '\'' +
               ", workedStatus='" + workedStatus + '\'' +
               '}';
    }
}
