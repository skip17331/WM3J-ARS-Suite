package com.hamradio.digitalbridge;

import com.hamradio.digitalbridge.ui.MainWindow;
import com.hamradio.digitalbridge.ui.SplashScreen;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.stage.Stage;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.logging.*;

/**
 * Application entry point for Digital Bridge.
 *
 * <p>Startup sequence:</p>
 * <ol>
 *   <li>Initialise java.util.logging to write to both console and a rolling log file.</li>
 *   <li>Load configuration from {@code digitalbridge-config.json}.</li>
 *   <li>Show splash screen.</li>
 *   <li>After splash, build all services and the main window.</li>
 *   <li>Begin hub WebSocket connection attempt (non-blocking).</li>
 *   <li>Start WSJT-X UDP listener (non-blocking, works without hub).</li>
 * </ol>
 *
 * <p>The application is fully functional without a hub connection — WSJT-X
 * decodes are shown in the local window regardless of hub availability.</p>
 */
public class DigitalBridgeMain extends Application {

    private static final Logger LOGGER = Logger.getLogger(DigitalBridgeMain.class.getName());

    // Services kept at field level so shutdown can reach them
    private HubClient        hubClient;
    private WsjtxUdpListener udpListener;

    // ── JavaFX entry point ────────────────────────────────────────────────────

    @Override
    public void start(Stage primaryStage) {
        // Show splash while we initialise in the background
        SplashScreen splash = new SplashScreen();
        splash.show(() -> Platform.runLater(() -> launchMainWindow(primaryStage)));
    }

    /**
     * Called on the FX thread after the splash screen has dismissed.
     * Builds all services and presents the main window.
     */
    private void launchMainWindow(Stage primaryStage) {
        try {
            ConfigManager cfg = ConfigManager.getInstance();

            // Create services
            hubClient   = new HubClient();
            udpListener = new WsjtxUdpListener(cfg.getWsjtxUdpPort(), cfg.getWsjtxBindAddress());

            MessagePublisher publisher = new MessagePublisher(hubClient);

            // Build and show main window (wires callbacks internally)
            MainWindow mainWindow = new MainWindow(hubClient, udpListener, publisher, primaryStage);
            mainWindow.show();

            // Connect to hub (non-blocking, with auto-reconnect)
            LOGGER.info("Connecting to hub at " + cfg.getHubUri());
            hubClient.connect(cfg.getHubUri());

            // Start UDP listener regardless of hub status
            LOGGER.info("Starting WSJT-X UDP listener on port " + cfg.getWsjtxUdpPort());
            udpListener.start();

        } catch (Exception e) {
            LOGGER.log(Level.SEVERE, "Fatal error during startup", e);
            Platform.exit();
        }
    }

    // ── Application shutdown ──────────────────────────────────────────────────

    @Override
    public void stop() {
        LOGGER.info("Application stopping — closing services");
        if (udpListener != null) udpListener.stop();
        if (hubClient   != null) hubClient.disconnect();
    }

    // ── Logging setup ─────────────────────────────────────────────────────────

    /**
     * Configure java.util.logging with a file handler and a console handler.
     * Called once before {@link Application#launch(Class, String...)}.
     */
    private static void configureLogging() {
        try {
            // Ensure log directory exists
            Files.createDirectories(Paths.get("logs"));

            Logger root = Logger.getLogger("");
            root.setLevel(Level.ALL);

            // Remove default handlers
            for (Handler h : root.getHandlers()) {
                root.removeHandler(h);
            }

            // Console handler — INFO and above
            ConsoleHandler console = new ConsoleHandler();
            console.setLevel(Level.INFO);
            console.setFormatter(new SimpleFormatter() {
                private static final String FMT = "[%1$tH:%1$tM:%1$tS] %2$-7s %3$s%n";
                @Override
                public synchronized String format(LogRecord lr) {
                    return String.format(FMT,
                            new java.util.Date(lr.getMillis()),
                            lr.getLevel().getLocalizedName(),
                            lr.getMessage());
                }
            });
            root.addHandler(console);

            // File handler — ALL levels, rolling
            FileHandler fileHandler = new FileHandler(
                    "logs/digitalbridge_%g.log", 5_000_000, 3, true);
            fileHandler.setLevel(Level.ALL);
            fileHandler.setFormatter(new SimpleFormatter());
            root.addHandler(fileHandler);

            // Quieten noisy third-party loggers
            Logger.getLogger("org.java_websocket").setLevel(Level.WARNING);
            Logger.getLogger("org.slf4j").setLevel(Level.WARNING);

        } catch (IOException e) {
            System.err.println("Warning: could not configure file logging — " + e.getMessage());
        }
    }

    // ── Main ──────────────────────────────────────────────────────────────────

    public static void main(String[] args) {
        configureLogging();

        // Load config before anything else
        ConfigManager.getInstance().load();

        LOGGER.info("Digital Bridge v1.0.0 starting");
        Application.launch(DigitalBridgeMain.class, args);
    }
}
