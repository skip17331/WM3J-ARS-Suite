package com.hamradio.digitalbridge;

import com.hamradio.digitalbridge.model.WsjtxDecode;
import com.hamradio.digitalbridge.model.WsjtxQsoLogged;
import com.hamradio.digitalbridge.model.WsjtxStatus;

import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.charset.StandardCharsets;
import java.time.Instant;
import java.time.LocalDate;
import java.time.ZoneOffset;
import java.time.temporal.JulianFields;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Decodes the WSJT-X binary UDP protocol as defined in
 * {@code Network/NetworkMessage.hpp} in the WSJT-X source tree.
 *
 * <h3>Wire format overview</h3>
 * <pre>
 *   Offset  Size  Field
 *   ------  ----  -----
 *      0     4    Magic number  0xADBCCBDA
 *      4     4    Schema number (quint32)
 *      8     4    Message type  (quint32)
 *     12     4    Id (utf8 length-prefixed string — the WSJT-X instance name)
 *    ...    ...   Type-specific payload
 * </pre>
 *
 * <p>All multi-byte integers are big-endian.  Strings are length-prefixed
 * (quint32 length + UTF-8 bytes; 0xFFFFFFFF signals a null/empty string).
 * QDateTime is encoded as a Julian day number (quint64) + milliseconds within
 * the day (quint32) + time-spec byte.</p>
 *
 * <p>Unrecognised message types are logged and silently skipped.  Any
 * decoding exception causes the packet to be skipped without crashing.</p>
 */
public class WsjtxProtocolDecoder {

    private static final Logger LOGGER = Logger.getLogger(WsjtxProtocolDecoder.class.getName());

    /** Magic number that identifies a WSJT-X UDP packet */
    private static final int WSJTX_MAGIC = 0xADBCCBDA;

    // ── Message type constants ─────────────────────────────────────────────────

    public static final int TYPE_HEARTBEAT   = 0;
    public static final int TYPE_STATUS      = 1;
    public static final int TYPE_DECODE      = 2;
    public static final int TYPE_CLEAR       = 3;
    public static final int TYPE_REPLY       = 4;
    public static final int TYPE_QSO_LOGGED  = 5;
    public static final int TYPE_CLOSE       = 6;
    public static final int TYPE_REPLAY      = 7;
    public static final int TYPE_HALT_TX     = 8;
    public static final int TYPE_FREE_TEXT   = 9;
    public static final int TYPE_WSPR_DECODE = 10;
    public static final int TYPE_LOCATION    = 11;
    public static final int TYPE_LOGGED_ADIF = 12;
    public static final int TYPE_HIGHLIGHT   = 13;
    public static final int TYPE_SWITCH_CONF = 14;
    public static final int TYPE_CONFIGURE   = 15;

    // ── Decoded result holder ─────────────────────────────────────────────────

    /**
     * Immutable result wrapper returned by {@link #decode(byte[])}.
     * Exactly one of the typed fields will be non-null depending on the
     * message type; use {@link #messageType} to discriminate.
     */
    public static class DecodedMessage {
        public final int messageType;
        public final String id;              // WSJT-X instance name
        public final int schemaVersion;

        // Typed payloads — at most one non-null per instance
        public final HeartbeatInfo heartbeat;
        public final WsjtxStatus   status;
        public final WsjtxDecode   decode;
        public final WsjtxQsoLogged qsoLogged;

        // Generic info for simple types
        public final String version; // heartbeat version string

        DecodedMessage(int type, String id, int schema,
                       HeartbeatInfo hb, WsjtxStatus st,
                       WsjtxDecode dc, WsjtxQsoLogged qso) {
            this.messageType  = type;
            this.id           = id;
            this.schemaVersion = schema;
            this.heartbeat    = hb;
            this.status       = st;
            this.decode       = dc;
            this.qsoLogged    = qso;
            this.version      = (hb != null) ? hb.version : null;
        }
    }

    /** Heartbeat-specific fields */
    public static class HeartbeatInfo {
        public final int    maxSchemaNumber;
        public final String version;
        public final String revision;

        HeartbeatInfo(int max, String version, String revision) {
            this.maxSchemaNumber = max;
            this.version         = version;
            this.revision        = revision;
        }
    }

    // ── Main decode entry point ───────────────────────────────────────────────

    /**
     * Decode a raw UDP datagram payload from WSJT-X.
     *
     * @param data raw bytes from DatagramPacket
     * @return decoded message, or {@code null} if the packet is malformed
     *         or the magic number does not match
     */
    public DecodedMessage decode(byte[] data) {
        try {
            ByteBuffer buf = ByteBuffer.wrap(data).order(ByteOrder.BIG_ENDIAN);

            // ── Header ──────────────────────────────────────────────────────
            int magic = buf.getInt();
            if (magic != WSJTX_MAGIC) {
                LOGGER.fine("Not a WSJT-X packet (magic mismatch)");
                return null;
            }

            int schema = buf.getInt();       // schema version
            int type   = buf.getInt();       // message type
            String id  = readUtf8(buf);      // instance identifier

            // ── Dispatch ────────────────────────────────────────────────────
            return switch (type) {
                case TYPE_HEARTBEAT  -> decodeHeartbeat(buf, id, schema);
                case TYPE_STATUS     -> decodeStatus(buf, id, schema);
                case TYPE_DECODE     -> decodeDecode(buf, id, schema);
                case TYPE_CLEAR      -> new DecodedMessage(TYPE_CLEAR, id, schema,
                                            null, null, null, null);
                case TYPE_QSO_LOGGED -> decodeQsoLogged(buf, id, schema);
                case TYPE_CLOSE      -> new DecodedMessage(TYPE_CLOSE, id, schema,
                                            null, null, null, null);
                default -> {
                    LOGGER.fine("Unhandled WSJT-X message type: " + type);
                    yield null;
                }
            };

        } catch (Exception e) {
            LOGGER.log(Level.WARNING, "Failed to decode WSJT-X packet: " + e.getMessage(), e);
            return null;
        }
    }

    // ── Type-specific decoders ────────────────────────────────────────────────

    /** Type 0 — Heartbeat */
    private DecodedMessage decodeHeartbeat(ByteBuffer buf, String id, int schema) {
        int    maxSchema = buf.getInt();           // quint32
        String version   = readUtf8(buf);
        String revision  = readUtf8(buf);
        HeartbeatInfo hb = new HeartbeatInfo(maxSchema, version, revision);
        return new DecodedMessage(TYPE_HEARTBEAT, id, schema, hb, null, null, null);
    }

    /** Type 1 — Status */
    private DecodedMessage decodeStatus(ByteBuffer buf, String id, int schema) {
        WsjtxStatus st = new WsjtxStatus();

        long   dialFreq    = buf.getLong();    // quint64
        String mode        = readUtf8(buf);
        String dxCall      = readUtf8(buf);
        String report      = readUtf8(buf);
        String txMode      = readUtf8(buf);    // (not exposed separately)
        boolean txEnabled  = buf.get() != 0;   // bool
        boolean transmit   = buf.get() != 0;   // bool
        boolean decoding   = buf.get() != 0;   // bool
        int     rxDf       = buf.getInt();     // quint32
        int     txDf       = buf.getInt();     // quint32
        String  dxGrid     = readUtf8(buf);
        boolean txWatchdog = buf.get() != 0;   // bool
        String  subMode    = readUtf8(buf);    // (not exposed)
        boolean fastMode   = buf.get() != 0;   // (not exposed)

        st.setDialFrequency(dialFreq);
        st.setMode(mode);
        st.setDxCall(nullIfEmpty(dxCall));
        st.setReport(nullIfEmpty(report));
        st.setTxEnabled(txEnabled);
        st.setTransmitting(transmit);
        st.setDecoding(decoding);
        st.setTxDf(txDf);
        st.setDxGrid(nullIfEmpty(dxGrid));
        st.setTxWatchdog(txWatchdog);
        st.setBand(SpotEnricher.frequencyToBand(dialFreq));

        return new DecodedMessage(TYPE_STATUS, id, schema, null, st, null, null);
    }

    /** Type 2 — Decode */
    private DecodedMessage decodeDecode(ByteBuffer buf, String id, int schema) {
        WsjtxDecode dc = new WsjtxDecode();

        boolean isNew        = buf.get() != 0;         // bool
        int     time         = buf.getInt();            // quint32 — ms since midnight UTC
        int     snr          = buf.getInt();            // qint32
        double  deltaTime    = buf.getDouble();         // double
        int     deltaFreq    = buf.getInt();            // quint32
        String  mode         = readUtf8(buf);
        String  message      = readUtf8(buf);
        boolean lowConf      = buf.get() != 0;         // bool
        boolean offAir       = buf.hasRemaining() && buf.get() != 0; // bool (schema 3+)

        // Reconstruct timestamp: today's date + time-of-day offset
        Instant ts = todayUtcMidnight().plusMillis(time);

        dc.setTimestamp(ts);
        dc.setSnr(snr);
        dc.setDeltaTime(deltaTime);
        dc.setDeltaFrequency(deltaFreq);
        dc.setMode(nullIfEmpty(mode));
        dc.setMessage(nullIfEmpty(message));
        dc.setLowConfidence(lowConf);
        dc.setOffAir(offAir);

        return new DecodedMessage(TYPE_DECODE, id, schema, null, null, dc, null);
    }

    /** Type 5 — QSO Logged */
    private DecodedMessage decodeQsoLogged(ByteBuffer buf, String id, int schema) {
        WsjtxQsoLogged qso = new WsjtxQsoLogged();

        Instant timeOff    = readQDateTime(buf);
        String  dxCall     = readUtf8(buf);
        String  dxGrid     = readUtf8(buf);
        long    dialFreq   = buf.getLong();       // quint64
        String  mode       = readUtf8(buf);
        String  rstSent    = readUtf8(buf);
        String  rstRecv    = readUtf8(buf);
        String  txPower    = readUtf8(buf);
        String  comments   = readUtf8(buf);
        String  name       = readUtf8(buf);
        Instant timeOn     = readQDateTime(buf);
        String  opCall     = readUtf8(buf);
        String  myCall     = readUtf8(buf);
        String  myGrid     = readUtf8(buf);
        String  exchSent   = readUtf8(buf);
        String  exchRecv   = readUtf8(buf);
        String  propMode   = buf.hasRemaining() ? readUtf8(buf) : "";

        qso.setTimestamp(timeOff != null ? timeOff : Instant.now());
        qso.setDxCall(nullIfEmpty(dxCall));
        qso.setDxGrid(nullIfEmpty(dxGrid));
        qso.setDialFrequency(dialFreq);
        qso.setMode(nullIfEmpty(mode));
        qso.setRstSent(nullIfEmpty(rstSent));
        qso.setRstReceived(nullIfEmpty(rstRecv));
        qso.setTxPower(nullIfEmpty(txPower));
        qso.setComments(nullIfEmpty(comments));
        qso.setName(nullIfEmpty(name));
        qso.setTimeOn(timeOn);
        qso.setTimeOff(timeOff);
        qso.setOperatorCall(nullIfEmpty(opCall));
        qso.setMyCall(nullIfEmpty(myCall));
        qso.setMyGrid(nullIfEmpty(myGrid));
        qso.setExchangeSent(nullIfEmpty(exchSent));
        qso.setExchangeReceived(nullIfEmpty(exchRecv));
        qso.setPropagationMode(nullIfEmpty(propMode));
        qso.setBand(SpotEnricher.frequencyToBand(dialFreq));

        return new DecodedMessage(TYPE_QSO_LOGGED, id, schema, null, null, null, qso);
    }

    // ── Wire-type helpers ─────────────────────────────────────────────────────

    /**
     * Read a WSJT-X length-prefixed UTF-8 string.
     * Returns an empty string if the length field is 0xFFFFFFFF (null sentinel).
     */
    private static String readUtf8(ByteBuffer buf) {
        int len = buf.getInt();
        if (len == 0xFFFFFFFF || len < 0) return ""; // null sentinel
        if (len == 0) return "";
        if (len > buf.remaining()) {
            LOGGER.warning("String length " + len + " exceeds remaining bytes " + buf.remaining());
            return "";
        }
        byte[] bytes = new byte[len];
        buf.get(bytes);
        return new String(bytes, StandardCharsets.UTF_8);
    }

    /**
     * Read a Qt QDateTime encoded as:
     *   quint64  Julian day number
     *   quint32  milliseconds since midnight
     *   quint8   time-spec (0=local, 1=UTC, 2=OffsetFromUTC, 3=TimeZone)
     *
     * Returns the corresponding {@link Instant} (UTC assumed for WSJT-X).
     */
    private static Instant readQDateTime(ByteBuffer buf) {
        try {
            long  julianDay = buf.getLong();
            int   msOfDay   = buf.getInt();
            byte  spec      = buf.get();

            // Julian Day Number → LocalDate in UTC
            // JDN 2440588 = 1970-01-01
            LocalDate date = LocalDate.MIN.with(JulianFields.JULIAN_DAY, julianDay);
            long epochSec  = date.atStartOfDay(ZoneOffset.UTC).toEpochSecond();
            return Instant.ofEpochMilli(epochSec * 1000L + msOfDay);
        } catch (Exception e) {
            LOGGER.fine("Failed to read QDateTime: " + e.getMessage());
            return Instant.now();
        }
    }

    /** UTC midnight of the current day as an Instant. */
    private static Instant todayUtcMidnight() {
        return LocalDate.now(ZoneOffset.UTC)
                        .atStartOfDay(ZoneOffset.UTC)
                        .toInstant();
    }

    /** Convert an empty string to null for cleaner model values. */
    private static String nullIfEmpty(String s) {
        return (s == null || s.isBlank()) ? null : s;
    }
}
