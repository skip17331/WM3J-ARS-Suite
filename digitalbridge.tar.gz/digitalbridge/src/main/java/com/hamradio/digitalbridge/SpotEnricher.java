package com.hamradio.digitalbridge;

import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

/**
 * Enriches a decoded spot with:
 * <ul>
 *   <li>Country, continent, and DXCC entity from a built-in prefix table</li>
 *   <li>Approximate lat/lon of the DX station</li>
 *   <li>True bearing and great-circle distance from our station</li>
 *   <li>Local time at the DX location</li>
 *   <li>Ham band derived from RF frequency</li>
 * </ul>
 *
 * <p>The built-in prefix table is intentionally abbreviated — a production
 * implementation would load the full DXCC entity list from a data file.
 * Unrecognised prefixes fall back to "Unknown" country with zero coordinates.</p>
 */
public class SpotEnricher {

    private static final Logger LOGGER = Logger.getLogger(SpotEnricher.class.getName());

    /** Earth radius in kilometres, used for Haversine distance calculation */
    private static final double EARTH_RADIUS_KM = 6371.0;

    /** Km per statute mile */
    private static final double KM_PER_MILE = 1.60934;

    // ── Our station location (set from hub or local config) ───────────────────

    private double myLat = 0.0;
    private double myLon = 0.0;

    // ── Singleton ─────────────────────────────────────────────────────────────

    private static SpotEnricher instance;

    private SpotEnricher() {}

    public static synchronized SpotEnricher getInstance() {
        if (instance == null) {
            instance = new SpotEnricher();
        }
        return instance;
    }

    // ── Location setters ──────────────────────────────────────────────────────

    public void setMyLocation(double lat, double lon) {
        this.myLat = lat;
        this.myLon = lon;
        LOGGER.info(String.format("Station location set: %.4f, %.4f", lat, lon));
    }

    public double getMyLat() { return myLat; }
    public double getMyLon() { return myLon; }

    // ── Public enrichment API ─────────────────────────────────────────────────

    /** DXCC entity data carrier */
    public static class DxccInfo {
        public final String country;
        public final String continent;
        public final int    dxcc;
        public final double lat;
        public final double lon;
        public final int    utcOffset; // hours offset from UTC

        DxccInfo(String country, String continent, int dxcc,
                 double lat, double lon, int utcOffset) {
            this.country   = country;
            this.continent = continent;
            this.dxcc      = dxcc;
            this.lat       = lat;
            this.lon       = lon;
            this.utcOffset = utcOffset;
        }
    }

    /**
     * Resolve DXCC information for the given amateur callsign.
     *
     * @param callsign upper-case callsign (may be null)
     * @return DxccInfo, never null (falls back to "Unknown" values)
     */
    public DxccInfo resolve(String callsign) {
        if (callsign == null || callsign.isBlank()) {
            return unknownEntity();
        }

        // Strip portable suffix for prefix lookup
        String base = callsign.toUpperCase();
        int slash = base.lastIndexOf('/');
        if (slash > 0 && (base.length() - slash - 1) <= 2) {
            base = base.substring(0, slash);
        }

        // Try longest prefix match first (up to 4 chars)
        for (int len = Math.min(4, base.length()); len >= 1; len--) {
            String prefix = base.substring(0, len);
            DxccInfo info = PREFIX_TABLE.get(prefix);
            if (info != null) return info;
        }
        return unknownEntity();
    }

    /**
     * Calculate true bearing (degrees) from our station to the DX lat/lon.
     */
    public double bearing(double toLat, double toLon) {
        if (myLat == 0 && myLon == 0) return 0;
        double lat1 = Math.toRadians(myLat);
        double lat2 = Math.toRadians(toLat);
        double dLon = Math.toRadians(toLon - myLon);

        double y = Math.sin(dLon) * Math.cos(lat2);
        double x = Math.cos(lat1) * Math.sin(lat2)
                 - Math.sin(lat1) * Math.cos(lat2) * Math.cos(dLon);
        double bearing = Math.toDegrees(Math.atan2(y, x));
        return (bearing + 360) % 360;
    }

    /**
     * Calculate great-circle distance in kilometres using the Haversine formula.
     */
    public double distanceKm(double toLat, double toLon) {
        if (myLat == 0 && myLon == 0) return 0;
        double lat1 = Math.toRadians(myLat);
        double lat2 = Math.toRadians(toLat);
        double dLat = Math.toRadians(toLat - myLat);
        double dLon = Math.toRadians(toLon - myLon);

        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2)
                 + Math.cos(lat1) * Math.cos(lat2)
                 * Math.sin(dLon / 2) * Math.sin(dLon / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return EARTH_RADIUS_KM * c;
    }

    /** Convert kilometres to statute miles. */
    public double toMiles(double km) {
        return km / KM_PER_MILE;
    }

    /**
     * Return the local time string ("HH:mm") at a location given its UTC offset.
     */
    public String localTimeAtSpot(int utcOffsetHours) {
        ZonedDateTime utcNow = ZonedDateTime.now(ZoneOffset.UTC);
        ZonedDateTime local  = utcNow.withZoneSameInstant(ZoneOffset.ofHours(utcOffsetHours));
        return local.format(DateTimeFormatter.ofPattern("HH:mm"));
    }

    // ── Band derivation ───────────────────────────────────────────────────────

    /**
     * Derive ham band string from RF frequency in Hz.
     * Returns "unknown" for unrecognised frequencies.
     */
    public static String frequencyToBand(long freqHz) {
        long kHz = freqHz / 1000L;
        if (kHz >= 1800  && kHz <= 2000)  return "160m";
        if (kHz >= 3500  && kHz <= 4000)  return "80m";
        if (kHz >= 5330  && kHz <= 5410)  return "60m";
        if (kHz >= 7000  && kHz <= 7300)  return "40m";
        if (kHz >= 10100 && kHz <= 10150) return "30m";
        if (kHz >= 14000 && kHz <= 14350) return "20m";
        if (kHz >= 18068 && kHz <= 18168) return "17m";
        if (kHz >= 21000 && kHz <= 21450) return "15m";
        if (kHz >= 24890 && kHz <= 24990) return "12m";
        if (kHz >= 28000 && kHz <= 29700) return "10m";
        if (kHz >= 50000 && kHz <= 54000) return "6m";
        if (kHz >= 144000 && kHz <= 148000) return "2m";
        return "unknown";
    }

    // ── Private helpers ───────────────────────────────────────────────────────

    private DxccInfo unknownEntity() {
        return new DxccInfo("Unknown", "??", 0, 0, 0, 0);
    }

    // ── Abbreviated prefix table ──────────────────────────────────────────────
    // Format: prefix → (country, continent, dxcc, lat, lon, utcOffset)
    // A full implementation would load this from the DXCC entity list data file.

    private static final Map<String, DxccInfo> PREFIX_TABLE = new HashMap<>();

    static {
        // North America
        add("W",   "United States",     291,  38.0,  -97.0, -5);
        add("K",   "United States",     291,  38.0,  -97.0, -5);
        add("N",   "United States",     291,  38.0,  -97.0, -5);
        add("AA",  "United States",     291,  38.0,  -97.0, -5);
        add("VE",  "Canada",            1,    56.0, -106.0, -5);
        add("VA",  "Canada",            1,    56.0, -106.0, -5);
        add("VY",  "Canada",            1,    56.0, -106.0, -5);
        add("XE",  "Mexico",            50,   23.0,  -102.0, -6);
        add("KP4", "Puerto Rico",       202,  18.2,  -66.5, -4);
        add("KH6", "Hawaii",            110,  21.3, -157.8, -10);
        add("KL7", "Alaska",            6,    64.2, -153.0, -9);

        // Europe
        add("G",   "England",           223,  52.0,   -1.0,  0);
        add("M",   "England",           223,  52.0,   -1.0,  0);
        add("DL",  "Germany",           230,  51.0,   10.0,  1);
        add("F",   "France",            227,  46.0,    2.0,  1);
        add("I",   "Italy",             248,  43.0,   12.0,  1);
        add("EA",  "Spain",             281,  40.0,   -4.0,  1);
        add("OK",  "Czech Republic",    503,  50.0,   15.0,  1);
        add("OH",  "Finland",           224,  64.0,   26.0,  2);
        add("SM",  "Sweden",            284,  60.0,   15.0,  1);
        add("LA",  "Norway",            266,  60.0,   10.0,  1);
        add("OZ",  "Denmark",           221,  56.0,   10.0,  1);
        add("PA",  "Netherlands",       263,  52.0,    5.0,  1);
        add("ON",  "Belgium",           209,  50.5,    4.5,  1);
        add("HB",  "Switzerland",       287,  47.0,    8.0,  1);
        add("OE",  "Austria",           206,  47.0,   14.0,  1);
        add("SP",  "Poland",            269,  52.0,   20.0,  1);
        add("HA",  "Hungary",           239,  47.0,   19.0,  1);
        add("YO",  "Romania",           275,  45.0,   25.0,  2);
        add("LZ",  "Bulgaria",          212,  43.0,   25.0,  2);
        add("SV",  "Greece",            236,  38.0,   23.0,  2);
        add("YU",  "Serbia",            296,  44.0,   21.0,  1);
        add("ES",  "Estonia",           52,   59.0,   25.0,  2);
        add("YL",  "Latvia",            145,  57.0,   25.0,  2);
        add("LY",  "Lithuania",         146,  55.0,   24.0,  2);
        add("EI",  "Ireland",           245,  53.0,   -8.0,  0);
        add("GI",  "Northern Ireland",  265,  54.5,   -6.5,  0);
        add("GM",  "Scotland",          279,  56.8,   -4.0,  0);
        add("GW",  "Wales",             294,  52.5,   -3.5,  0);
        add("CT",  "Portugal",          272,  39.0,   -8.0,  0);
        add("UA",  "Russia",            54,   60.0,   60.0,  3);
        add("RK",  "Russia",            54,   60.0,   60.0,  3);
        add("RA",  "Russia",            54,   60.0,   60.0,  3);
        add("R",   "Russia",            54,   60.0,   60.0,  3);

        // Asia / Pacific
        add("JA",  "Japan",             339,  36.0,  138.0,  9);
        add("JH",  "Japan",             339,  36.0,  138.0,  9);
        add("JR",  "Japan",             339,  36.0,  138.0,  9);
        add("BY",  "China",             318,  35.0,  105.0,  8);
        add("BT",  "China",             318,  35.0,  105.0,  8);
        add("HL",  "South Korea",       137,  37.0,  127.0,  9);
        add("DS",  "South Korea",       137,  37.0,  127.0,  9);
        add("VK",  "Australia",         150,  -25.0, 133.0, 10);
        add("ZL",  "New Zealand",       170,  -41.0, 174.0, 12);
        add("9V",  "Singapore",         381,   1.3,  103.8,  8);
        add("HS",  "Thailand",          387,  15.0,  101.0,  7);
        add("VU",  "India",             324,  20.0,   77.0,  6);

        // South America
        add("PY",  "Brazil",            108,  -10.0, -55.0, -3);
        add("LU",  "Argentina",         100,  -34.0, -64.0, -3);
        add("CE",  "Chile",             112,  -30.0, -71.0, -4);
        add("HC",  "Ecuador",           120,   -2.0, -78.0, -5);
        add("OA",  "Peru",              136,  -10.0, -76.0, -5);
        add("YV",  "Venezuela",         148,    8.0, -66.0, -4);
        add("HK",  "Colombia",          116,    4.0, -74.0, -5);

        // Africa
        add("ZS",  "South Africa",      462,  -29.0,  25.0,  2);
        add("5B",  "Cyprus",            215,   35.0,  33.0,  2);
        add("EA8", "Canary Islands",    29,    28.0, -15.0,  0);
        add("TF",  "Iceland",           242,   65.0, -18.0,  0);
        add("5N",  "Nigeria",           450,    9.0,   8.0,  1);
        add("9J",  "Zambia",            482,  -13.0,  28.0,  2);

        // Middle East
        add("4X",  "Israel",            336,   31.5,  35.0,  2);
        add("A9",  "Bahrain",           304,   26.0,  50.5,  3);
        add("A4",  "Oman",              370,   23.0,  58.0,  4);
    }

    /** Helper to reduce prefix table initialisation verbosity. */
    private static void add(String prefix, String country, int dxcc,
                            double lat, double lon, int utcOffset) {
        // Continent derived from rough lat/lon mapping
        String continent = deriveContinent(lat, lon, country);
        PREFIX_TABLE.put(prefix, new DxccInfo(country, continent, dxcc, lat, lon, utcOffset));
    }

    /** Very rough continent guess from coordinates — good enough for display. */
    private static String deriveContinent(double lat, double lon, String country) {
        // European check
        if (lat > 35 && lat < 72 && lon > -25 && lon < 45) return "EU";
        // North America
        if (lat > 15 && lat < 85 && lon > -170 && lon < -50) return "NA";
        // South America
        if (lat > -60 && lat < 15 && lon > -85 && lon < -30) return "SA";
        // Asia
        if (lat > 0 && lat < 75 && lon > 40 && lon < 180) return "AS";
        // Pacific / Oceania
        if (lat > -50 && lat < 0 && lon > 110 && lon < 180) return "OC";
        // Africa
        if (lat > -40 && lat < 40 && lon > -20 && lon < 55) return "AF";
        return "??";
    }
}
