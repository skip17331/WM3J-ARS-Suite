package com.hamradio.digitalbridge;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;
import java.util.logging.Logger;

/**
 * Maintains a thread-safe set of callsigns that our station has already worked.
 *
 * <p>The list is populated from the hub on connect and is updated whenever a
 * {@code WSJTX_QSO_LOGGED} event is processed.  Each decoded callsign is
 * checked against this list to produce the {@code workedStatus} field
 * ("worked", "needed", or "unknown").</p>
 */
public class WorkedListManager {

    private static final Logger LOGGER = Logger.getLogger(WorkedListManager.class.getName());

    /** Thread-safe set of worked callsigns in upper-case */
    private final Set<String> workedCallsigns =
            Collections.synchronizedSet(new HashSet<>());

    // ── Singleton ─────────────────────────────────────────────────────────────

    private static WorkedListManager instance;

    private WorkedListManager() {}

    public static synchronized WorkedListManager getInstance() {
        if (instance == null) {
            instance = new WorkedListManager();
        }
        return instance;
    }

    // ── Public API ────────────────────────────────────────────────────────────

    /**
     * Replace the entire worked list with the supplied callsigns.
     * Called when the hub sends the initial callsign list on connect.
     *
     * @param callsigns iterable of callsigns (will be upper-cased)
     */
    public void setWorkedList(Iterable<String> callsigns) {
        workedCallsigns.clear();
        if (callsigns != null) {
            for (String cs : callsigns) {
                if (cs != null && !cs.isBlank()) {
                    workedCallsigns.add(cs.trim().toUpperCase());
                }
            }
        }
        LOGGER.info("Worked list loaded: " + workedCallsigns.size() + " callsigns");
    }

    /**
     * Mark a callsign as worked.
     * Typically called after receiving a {@code WSJTX_QSO_LOGGED} event.
     *
     * @param callsign the worked station's callsign
     */
    public void markWorked(String callsign) {
        if (callsign == null || callsign.isBlank()) return;
        String cs = callsign.trim().toUpperCase();
        boolean added = workedCallsigns.add(cs);
        if (added) {
            LOGGER.fine("Marked as worked: " + cs);
        }
    }

    /**
     * Clear the worked list.
     */
    public void clear() {
        workedCallsigns.clear();
        LOGGER.info("Worked list cleared");
    }

    /**
     * Determine the worked status of the given callsign.
     *
     * @param callsign callsign to check (may be null)
     * @return "worked", "needed", or "unknown"
     */
    public String getWorkedStatus(String callsign) {
        if (callsign == null || callsign.isBlank()) {
            return "unknown";
        }
        String cs = callsign.trim().toUpperCase();
        if (workedCallsigns.contains(cs)) {
            return "worked";
        }
        // If the list is non-empty we can say "needed"; if empty we say "unknown"
        // because we haven't received a list yet.
        return workedCallsigns.isEmpty() ? "unknown" : "needed";
    }

    /**
     * Returns true if the callsign has been worked.
     */
    public boolean isWorked(String callsign) {
        if (callsign == null || callsign.isBlank()) return false;
        return workedCallsigns.contains(callsign.trim().toUpperCase());
    }

    /**
     * Returns the number of callsigns in the worked list.
     */
    public int size() {
        return workedCallsigns.size();
    }

    /**
     * Returns an unmodifiable snapshot of the worked callsign set.
     */
    public Set<String> snapshot() {
        return Collections.unmodifiableSet(new HashSet<>(workedCallsigns));
    }
}
