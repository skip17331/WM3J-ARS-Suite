package com.hamradio.digitalbridge;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.hamradio.digitalbridge.model.WsjtxDecode;
import com.hamradio.digitalbridge.model.WsjtxQsoLogged;
import com.hamradio.digitalbridge.model.WsjtxStatus;

import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.util.logging.Logger;

/**
 * Formats domain objects as hub-protocol JSON and publishes them via
 * {@link HubClient}.
 *
 * <p>All formatting is done here so that the rest of the application is
 * insulated from the exact JSON schema expected by the hub.</p>
 */
public class MessagePublisher {

    private static final Logger LOGGER = Logger.getLogger(MessagePublisher.class.getName());

    private static final DateTimeFormatter ISO_UTC =
            DateTimeFormatter.ISO_INSTANT.withZone(ZoneOffset.UTC);

    private final Gson gson = new GsonBuilder().create();
    private final HubClient hubClient;

    public MessagePublisher(HubClient hubClient) {
        this.hubClient = hubClient;
    }

    // ── Registration message ──────────────────────────────────────────────────

    /**
     * Send the APP_CONNECTED registration message immediately after the
     * WebSocket connection is established.
     */
    public void sendAppConnected() {
        JsonObject msg = new JsonObject();
        msg.addProperty("type",    "APP_CONNECTED");
        msg.addProperty("appName", "digitalBridge");
        msg.addProperty("version", "1.0.0");
        send(msg);
    }

    // ── WSJT-X event publishers ───────────────────────────────────────────────

    /**
     * Publish an enriched WSJTX_DECODE message to the hub.
     */
    public void publishDecode(WsjtxDecode decode) {
        JsonObject msg = new JsonObject();
        msg.addProperty("type",           "WSJTX_DECODE");
        msg.addProperty("callsign",       nullToEmpty(decode.getCallsign()));
        msg.addProperty("frequency",      decode.getFrequency());
        msg.addProperty("band",           nullToEmpty(decode.getBand()));
        msg.addProperty("mode",           nullToEmpty(decode.getMode()));
        msg.addProperty("snr",            decode.getSnr());
        msg.addProperty("deltaTime",      decode.getDeltaTime());
        msg.addProperty("message",        nullToEmpty(decode.getMessage()));
        msg.addProperty("timestamp",      formatInstant(decode.getTimestamp()));
        msg.addProperty("lat",            decode.getLat());
        msg.addProperty("lon",            decode.getLon());
        msg.addProperty("country",        nullToEmpty(decode.getCountry()));
        msg.addProperty("continent",      nullToEmpty(decode.getContinent()));
        msg.addProperty("dxcc",           decode.getDxcc());
        msg.addProperty("bearing",        round2(decode.getBearing()));
        msg.addProperty("distanceKm",     round1(decode.getDistanceKm()));
        msg.addProperty("distanceMi",     round1(decode.getDistanceMi()));
        msg.addProperty("localTimeAtSpot",nullToEmpty(decode.getLocalTimeAtSpot()));
        msg.addProperty("workedStatus",   nullToEmpty(decode.getWorkedStatus()));
        send(msg);
    }

    /**
     * Publish a WSJTX_STATUS message to the hub.
     */
    public void publishStatus(WsjtxStatus status) {
        JsonObject msg = new JsonObject();
        msg.addProperty("type",        "WSJTX_STATUS");
        msg.addProperty("frequency",   status.getDialFrequency());
        msg.addProperty("mode",        nullToEmpty(status.getMode()));
        msg.addProperty("band",        nullToEmpty(status.getBand()));
        msg.addProperty("transmitting",status.isTransmitting());
        msg.addProperty("decoding",    status.isDecoding());
        msg.addProperty("dxCall",      nullToEmpty(status.getDxCall()));
        msg.addProperty("report",      nullToEmpty(status.getReport()));
        msg.addProperty("txEnabled",   status.isTxEnabled());
        send(msg);
    }

    /**
     * Publish a WSJTX_QSO_LOGGED message to the hub.
     */
    public void publishQsoLogged(WsjtxQsoLogged qso) {
        JsonObject msg = new JsonObject();
        msg.addProperty("type",         "WSJTX_QSO_LOGGED");
        msg.addProperty("callsign",     nullToEmpty(qso.getDxCall()));
        msg.addProperty("frequency",    qso.getDialFrequency());
        msg.addProperty("mode",         nullToEmpty(qso.getMode()));
        msg.addProperty("band",         nullToEmpty(qso.getBand()));
        msg.addProperty("rstSent",      nullToEmpty(qso.getRstSent()));
        msg.addProperty("rstReceived",  nullToEmpty(qso.getRstReceived()));
        msg.addProperty("timestamp",    formatInstant(qso.getTimestamp()));
        msg.addProperty("country",      nullToEmpty(qso.getCountry()));
        msg.addProperty("continent",    nullToEmpty(qso.getContinent()));
        msg.addProperty("dxcc",         qso.getDxcc());
        msg.addProperty("name",         nullToEmpty(qso.getName()));
        msg.addProperty("comment",      nullToEmpty(qso.getComments()));
        send(msg);
    }

    /**
     * Publish a WSJTX_CONNECTION status message to the hub.
     */
    public void publishConnectionStatus(boolean connected, String version) {
        JsonObject msg = new JsonObject();
        msg.addProperty("type",      "WSJTX_CONNECTION");
        msg.addProperty("connected", connected);
        msg.addProperty("version",   version != null ? version : "");
        msg.addProperty("timestamp", formatInstant(Instant.now()));
        send(msg);
    }

    // ── Delivery ─────────────────────────────────────────────────────────────

    private void send(JsonObject msg) {
        if (hubClient != null && hubClient.isConnected()) {
            String json = gson.toJson(msg);
            LOGGER.fine("→ HUB: " + json);
            hubClient.send(json);
        }
    }

    // ── Utilities ─────────────────────────────────────────────────────────────

    private String formatInstant(Instant instant) {
        if (instant == null) instant = Instant.now();
        return ISO_UTC.format(instant);
    }

    private String nullToEmpty(String s) {
        return s != null ? s : "";
    }

    private double round1(double v) {
        return Math.round(v * 10.0) / 10.0;
    }

    private double round2(double v) {
        return Math.round(v * 100.0) / 100.0;
    }
}
