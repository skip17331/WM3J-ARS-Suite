package com.hamradio.digitalbridge.ui;

import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Circle;

/**
 * Panel displaying the current hub WebSocket connection status.
 *
 * Shows:
 * <ul>
 *   <li>Connected / disconnected indicator (coloured circle)</li>
 *   <li>Hub address and port</li>
 *   <li>Messages sent and received counters</li>
 *   <li>Reconnect button</li>
 * </ul>
 */
public class HubStatusPanel extends VBox {

    private final Circle  indicator    = new Circle(6);
    private final Label   statusLbl    = fieldValue("Disconnected");
    private final Label   addressLbl   = fieldValue("-");
    private final Label   sentLbl      = fieldValue("0");
    private final Label   receivedLbl  = fieldValue("0");
    private final Button  reconnectBtn = new Button("Reconnect");

    /** Callback invoked when the user presses Reconnect */
    private Runnable onReconnect;

    public HubStatusPanel(String address, int port) {
        setSpacing(4);
        setPadding(new Insets(8));
        setStyle("-fx-background-color: #111122; -fx-border-color: #2a2a4a; -fx-border-width: 0 0 1 0;");

        Label header = new Label("Hub");
        header.setStyle("-fx-text-fill: #00d4ff; -fx-font-size: 12px; -fx-font-weight: bold;");

        indicator.setFill(javafx.scene.paint.Color.web("#555555"));
        HBox statusRow = new HBox(6, indicator, statusLbl);
        statusRow.setStyle("-fx-alignment: center-left;");

        addressLbl.setText(address + ":" + port);

        reconnectBtn.setStyle("-fx-background-color: #2a2a5a; -fx-text-fill: #cccccc; " +
                              "-fx-font-size: 11px; -fx-cursor: hand;");
        reconnectBtn.setOnAction(e -> { if (onReconnect != null) onReconnect.run(); });
        reconnectBtn.setPrefHeight(22);

        GridPane grid = new GridPane();
        grid.setHgap(8);
        grid.setVgap(2);
        grid.setPadding(new Insets(4, 0, 0, 0));

        int r = 0;
        grid.add(fieldKey("Status:"),   0, r); grid.add(statusRow,    1, r++);
        grid.add(fieldKey("Address:"),  0, r); grid.add(addressLbl,   1, r++);
        grid.add(fieldKey("Sent:"),     0, r); grid.add(sentLbl,      1, r++);
        grid.add(fieldKey("Received:"), 0, r); grid.add(receivedLbl,  1, r++);
        grid.add(reconnectBtn, 0, r, 2, 1);

        getChildren().addAll(header, grid);
    }

    // ── Public update methods (call on FX thread) ─────────────────────────────

    /** Update the connection indicator and status label. */
    public void setConnected(boolean connected, String hubUri) {
        if (connected) {
            indicator.setFill(javafx.scene.paint.Color.web("#00dd00"));
            statusLbl.setText("Connected");
            if (hubUri != null) addressLbl.setText(hubUri);
        } else {
            indicator.setFill(javafx.scene.paint.Color.web("#555555"));
            statusLbl.setText("Disconnected");
        }
    }

    /** Update the messages-sent counter. */
    public void setSentCount(long count) {
        sentLbl.setText(String.valueOf(count));
    }

    /** Update the messages-received counter. */
    public void setReceivedCount(long count) {
        receivedLbl.setText(String.valueOf(count));
    }

    /** Register a callback for the Reconnect button. */
    public void setOnReconnect(Runnable onReconnect) {
        this.onReconnect = onReconnect;
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private static Label fieldKey(String text) {
        Label l = new Label(text);
        l.setStyle("-fx-text-fill: #888888; -fx-font-size: 11px;");
        return l;
    }

    private static Label fieldValue(String text) {
        Label l = new Label(text);
        l.setStyle("-fx-text-fill: #cccccc; -fx-font-size: 11px;");
        return l;
    }
}
