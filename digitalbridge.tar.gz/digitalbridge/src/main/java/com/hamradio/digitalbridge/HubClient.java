package com.hamradio.digitalbridge;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import org.java_websocket.client.WebSocketClient;
import org.java_websocket.handshake.ServerHandshake;

import java.net.URI;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.ScheduledFuture;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicLong;
import java.util.function.BiConsumer;
import java.util.function.Consumer;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * WebSocket client that connects to the ham radio suite hub server.
 *
 * <p>Provides automatic reconnection with exponential back-off (max 30 s).
 * Implements callbacks for the application to react to hub messages without
 * coupling to the WebSocket implementation.</p>
 *
 * <p>Thread safety: callbacks are invoked on the WebSocket receive thread.
 * The JavaFX layer wraps these in {@code Platform.runLater()} where needed.</p>
 */
public class HubClient {

    private static final Logger LOGGER = Logger.getLogger(HubClient.class.getName());

    // ── Reconnect back-off parameters ────────────────────────────────────────

    private static final long RECONNECT_INITIAL_MS = 2_000L;
    private static final long RECONNECT_MAX_MS     = 30_000L;

    // ── State ─────────────────────────────────────────────────────────────────

    private String uri;
    private volatile boolean wantConnected = false;
    private volatile long reconnectDelayMs = RECONNECT_INITIAL_MS;

    private WebSocketClient ws;
    private final ScheduledExecutorService scheduler =
            Executors.newSingleThreadScheduledExecutor(r -> {
                Thread t = new Thread(r, "hub-reconnect");
                t.setDaemon(true);
                return t;
            });
    private ScheduledFuture<?> reconnectFuture;

    // ── Counters ──────────────────────────────────────────────────────────────

    private final AtomicLong messagesSent     = new AtomicLong();
    private final AtomicLong messagesReceived = new AtomicLong();

    // ── Callbacks ─────────────────────────────────────────────────────────────

    /** Called with (true, hubUri) on connect, (false, reason) on disconnect */
    private BiConsumer<Boolean, String> onConnectionChange;

    /** Called for every JSON message received from the hub */
    private Consumer<JsonObject> onMessage;

    // ── Public API ────────────────────────────────────────────────────────────

    /**
     * Connect to the hub at the given WebSocket URI.
     * Returns immediately; connection attempt is asynchronous.
     *
     * @param uri e.g. "ws://localhost:8080"
     */
    public synchronized void connect(String uri) {
        this.uri = uri;
        this.wantConnected = true;
        reconnectDelayMs = RECONNECT_INITIAL_MS;
        doConnect();
    }

    /**
     * Disconnect from the hub and stop automatic reconnection.
     */
    public synchronized void disconnect() {
        wantConnected = false;
        cancelReconnect();
        if (ws != null) {
            try { ws.close(); } catch (Exception ignored) {}
        }
        LOGGER.info("Hub client disconnected");
    }

    /**
     * Send a raw JSON string to the hub.
     * No-op if not connected.
     */
    public void send(String json) {
        WebSocketClient current = ws;
        if (current != null && current.isOpen()) {
            try {
                current.send(json);
                messagesSent.incrementAndGet();
            } catch (Exception e) {
                LOGGER.log(Level.WARNING, "Failed to send to hub: " + e.getMessage(), e);
            }
        }
    }

    /** Returns true if the WebSocket connection is open. */
    public boolean isConnected() {
        return ws != null && ws.isOpen();
    }

    /** Number of messages successfully sent to the hub this session. */
    public long getMessagesSent() { return messagesSent.get(); }

    /** Number of messages received from the hub this session. */
    public long getMessagesReceived() { return messagesReceived.get(); }

    // ── Callback setters ──────────────────────────────────────────────────────

    public void setOnConnectionChange(BiConsumer<Boolean, String> cb) {
        this.onConnectionChange = cb;
    }

    public void setOnMessage(Consumer<JsonObject> cb) {
        this.onMessage = cb;
    }

    // ── Internal connection logic ─────────────────────────────────────────────

    private void doConnect() {
        if (!wantConnected) return;
        cancelReconnect();

        try {
            URI endpoint = new URI(uri);
            ws = new WebSocketClient(endpoint) {

                @Override
                public void onOpen(ServerHandshake hs) {
                    LOGGER.info("Hub connected: " + uri);
                    reconnectDelayMs = RECONNECT_INITIAL_MS; // reset back-off
                    if (onConnectionChange != null) {
                        onConnectionChange.accept(true, uri);
                    }
                }

                @Override
                public void onMessage(String text) {
                    messagesReceived.incrementAndGet();
                    LOGGER.fine("← HUB: " + text);
                    if (onMessage != null) {
                        try {
                            JsonObject json = JsonParser.parseString(text).getAsJsonObject();
                            onMessage.accept(json);
                        } catch (Exception e) {
                            LOGGER.log(Level.WARNING,
                                       "Failed to parse hub message: " + text, e);
                        }
                    }
                }

                @Override
                public void onClose(int code, String reason, boolean remote) {
                    LOGGER.info(String.format("Hub disconnected (code=%d, reason=%s, remote=%b)",
                                              code, reason, remote));
                    if (onConnectionChange != null) {
                        onConnectionChange.accept(false, reason);
                    }
                    scheduleReconnect();
                }

                @Override
                public void onError(Exception e) {
                    LOGGER.log(Level.WARNING, "Hub WebSocket error: " + e.getMessage(), e);
                }
            };

            ws.connect();

        } catch (Exception e) {
            LOGGER.log(Level.WARNING, "Hub connection failed: " + e.getMessage(), e);
            scheduleReconnect();
        }
    }

    private void scheduleReconnect() {
        if (!wantConnected) return;
        long delay = reconnectDelayMs;
        // Exponential back-off capped at max
        reconnectDelayMs = Math.min(reconnectDelayMs * 2, RECONNECT_MAX_MS);
        LOGGER.info("Hub reconnecting in " + delay + " ms…");
        reconnectFuture = scheduler.schedule(this::doConnect, delay, TimeUnit.MILLISECONDS);
    }

    private void cancelReconnect() {
        if (reconnectFuture != null && !reconnectFuture.isDone()) {
            reconnectFuture.cancel(false);
        }
    }
}
