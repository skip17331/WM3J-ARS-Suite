package com.hamradio.digitalbridge;

import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.logging.Logger;

/**
 * Parses the DX callsign from WSJT-X decoded message text.
 *
 * <p>WSJT-X message formats include:</p>
 * <pre>
 *   CQ W3ABC FM19            → DX = W3ABC
 *   CQ DX W3ABC FM19         → DX = W3ABC
 *   CQ NA W3ABC FM19         → DX = W3ABC  (directional CQ)
 *   W3ABC K3XYZ -10          → DX = W3ABC  (first call is DX, second is our station)
 *   W3ABC K3XYZ RR73         → DX = W3ABC
 *   TU; K3XYZ W3ABC -08      → DX = W3ABC  (TU format; DX is 2nd call after "TU;")
 *   K3XYZ W3ABC R-08         → DX = W3ABC  (R-report; DX is 2nd call)
 *   DE W3ABC FM19            → DX = W3ABC
 * </pre>
 *
 * <p>The parser is intentionally conservative: when the callsign cannot be
 * extracted with confidence, it returns {@code null} rather than guessing.</p>
 */
public class CallsignParser {

    private static final Logger LOGGER = Logger.getLogger(CallsignParser.class.getName());

    /**
     * Regex pattern matching a valid amateur callsign.
     *
     * Covers formats such as:
     *   W3ABC, K3XYZ, VK3ABC, OH2BH, 5B4AIF, ZL2IFB, OZ/DL3YM, W3ABC/P
     */
    private static final Pattern CALLSIGN_PATTERN =
            Pattern.compile("\\b([A-Z0-9]{1,3}/)?([A-Z]{1,2}[0-9][A-Z]{1,4})(/[A-Z0-9]+)?\\b");

    /** Tokens that are definitively NOT callsigns in WSJT-X messages */
    private static final java.util.Set<String> RESERVED_TOKENS = new java.util.HashSet<>(
            java.util.Arrays.asList(
                    "CQ", "DE", "DX", "NA", "EU", "AS", "AF", "OC", "SA",
                    "RR73", "73", "RRR", "TU", "ACK",
                    "R-", "R+", "RR"
            ));

    private CallsignParser() {}

    /**
     * Extract the DX callsign from a WSJT-X message string.
     *
     * @param message raw decoded message text (may be null or empty)
     * @return extracted callsign in upper-case, or {@code null} if not found
     */
    public static String extractDxCallsign(String message) {
        if (message == null || message.isBlank()) {
            return null;
        }

        String msg = message.trim().toUpperCase();

        // ── CQ messages ───────────────────────────────────────────────────────
        // Format: "CQ [<modifier>] <CALLSIGN> [<GRID>]"
        if (msg.startsWith("CQ ")) {
            String rest = msg.substring(3).trim();
            String[] parts = rest.split("\\s+");
            for (String part : parts) {
                if (!RESERVED_TOKENS.contains(part) && isCallsign(part)) {
                    return stripSuffix(part);
                }
            }
            return null;
        }

        // ── DE messages ───────────────────────────────────────────────────────
        // Format: "DE <CALLSIGN> [<GRID>]"
        if (msg.startsWith("DE ")) {
            String[] parts = msg.split("\\s+");
            if (parts.length >= 2 && isCallsign(parts[1])) {
                return stripSuffix(parts[1]);
            }
            return null;
        }

        // ── TU; prefix messages ───────────────────────────────────────────────
        // Format: "TU; <OUR_CALL> <DX_CALL> <REPORT>"
        if (msg.startsWith("TU;")) {
            String[] parts = msg.split("\\s+");
            if (parts.length >= 3 && isCallsign(parts[2])) {
                return stripSuffix(parts[2]);
            }
            return null;
        }

        // ── Standard two-callsign exchange ────────────────────────────────────
        // Format: "<DX_CALL> <OUR_CALL> <REPORT|RR73|73|RRR>"
        // Format: "<OUR_CALL> <DX_CALL> R<REPORT>"
        String[] tokens = msg.split("\\s+");
        if (tokens.length >= 2) {
            // Count callsign-like tokens
            java.util.List<String> calls = new java.util.ArrayList<>();
            for (String token : tokens) {
                if (!RESERVED_TOKENS.contains(token) && isCallsign(token)) {
                    calls.add(stripSuffix(token));
                }
            }
            if (calls.size() == 1) {
                return calls.get(0);
            }
            if (calls.size() >= 2) {
                // Convention: first callsign in message is the DX station
                // when format is "<DX> <OUR> <REPORT>"
                // Detect R-report format (third token starts with R) meaning
                // format is "<OUR> <DX> R<REPORT>" — DX is the second call
                if (tokens.length >= 3) {
                    String thirdToken = tokens[2];
                    if (thirdToken.matches("R[+-]?\\d+")) {
                        // "<OUR> <DX> R<REPORT>" — DX is second call
                        return calls.get(1);
                    }
                }
                // Default: first callsign is DX
                return calls.get(0);
            }
        }

        LOGGER.fine("Could not extract callsign from: " + message);
        return null;
    }

    /**
     * Returns true if {@code token} looks like a valid amateur callsign.
     * Does NOT match grid squares (e.g. "FM19") or report strings ("-10").
     */
    public static boolean isCallsign(String token) {
        if (token == null || token.length() < 3 || token.length() > 14) {
            return false;
        }
        if (RESERVED_TOKENS.contains(token)) {
            return false;
        }
        // Grid locators are 4 or 6 chars: 2 letters + 2 digits [+ 2 letters]
        if (token.matches("[A-R]{2}[0-9]{2}([A-X]{2})?")) {
            return false;
        }
        // Signal reports like -10, +02, R-08
        if (token.matches("[R]?[+-]?\\d+")) {
            return false;
        }
        return CALLSIGN_PATTERN.matcher(token).matches();
    }

    /**
     * Strip portable/mobile suffixes from a callsign for consistent lookup.
     * E.g. "W3ABC/P" → "W3ABC", "OZ/DL3YM" → preserved as "OZ/DL3YM".
     */
    private static String stripSuffix(String callsign) {
        // Remove trailing /P /M /MM /AM etc. but keep prefix/call separator
        int lastSlash = callsign.lastIndexOf('/');
        if (lastSlash > 0) {
            String suffix = callsign.substring(lastSlash + 1);
            if (suffix.length() <= 2 && suffix.matches("[A-Z0-9]+")) {
                return callsign.substring(0, lastSlash);
            }
        }
        return callsign;
    }
}
