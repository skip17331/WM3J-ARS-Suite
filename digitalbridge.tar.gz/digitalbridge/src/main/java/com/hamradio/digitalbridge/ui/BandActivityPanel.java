package com.hamradio.digitalbridge.ui;

import com.hamradio.digitalbridge.model.BandActivity;
import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.control.ScrollPane;
import javafx.scene.layout.*;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Side panel showing per-band spot count and the best DX heard on each band.
 *
 * <pre>
 *   Band   Spots  Top DX
 *   160m       0  -
 *    80m       3  JA1ABC
 *    40m      12  VK3ABC
 *    20m      45  ZL2IFB
 * </pre>
 */
public class BandActivityPanel extends VBox {

    private static final String[] BANDS = {
        "160m","80m","60m","40m","30m","20m","17m","15m","12m","10m","6m","2m"
    };

    /** Maps band → row labels {spots, topDx} */
    private final Map<String, Label[]> rows = new LinkedHashMap<>();

    public BandActivityPanel() {
        setSpacing(0);
        setPadding(new Insets(4));
        setStyle("-fx-background-color: #111122; -fx-min-width: 170px;");

        // Header
        HBox header = rowBox(
                styledLabel("Band",   70, true),
                styledLabel("Spots",  45, true),
                styledLabel("Top DX", 70, true));
        header.setStyle("-fx-background-color: #1e1e3a; -fx-padding: 4 2 4 2;");
        getChildren().add(header);

        // One row per band
        for (int i = 0; i < BANDS.length; i++) {
            String band = BANDS[i];
            Label spotsLbl = styledLabel("0",  45, false);
            Label topLbl   = styledLabel("-",  70, false);
            rows.put(band, new Label[]{ spotsLbl, topLbl });

            HBox row = rowBox(styledLabel(band, 70, false), spotsLbl, topLbl);
            row.setStyle(i % 2 == 0
                    ? "-fx-background-color: #0d0d1a; -fx-padding: 3 2 3 2;"
                    : "-fx-background-color: #111122; -fx-padding: 3 2 3 2;");
            getChildren().add(row);
        }
    }

    // ── Public API ────────────────────────────────────────────────────────────

    /**
     * Update the display for one band.
     * Must be called on the JavaFX Application Thread.
     */
    public void update(BandActivity activity) {
        Label[] lbls = rows.get(activity.getBand());
        if (lbls == null) return;
        lbls[0].setText(String.valueOf(activity.getSpotCount()));
        lbls[1].setText(activity.getTopDxCall());
    }

    /** Reset all band counters to zero. */
    public void reset() {
        rows.values().forEach(lbls -> {
            lbls[0].setText("0");
            lbls[1].setText("-");
        });
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private HBox rowBox(Label... labels) {
        HBox box = new HBox();
        box.getChildren().addAll(labels);
        return box;
    }

    private Label styledLabel(String text, double width, boolean header) {
        Label lbl = new Label(text);
        lbl.setPrefWidth(width);
        lbl.setStyle(header
                ? "-fx-text-fill: #00d4ff; -fx-font-size: 11px; -fx-font-weight: bold;"
                : "-fx-text-fill: #cccccc; -fx-font-size: 11px;");
        return lbl;
    }
}
