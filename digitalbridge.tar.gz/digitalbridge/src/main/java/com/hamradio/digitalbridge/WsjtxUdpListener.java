package com.hamradio.digitalbridge;

import com.hamradio.digitalbridge.model.WsjtxDecode;
import com.hamradio.digitalbridge.model.WsjtxQsoLogged;
import com.hamradio.digitalbridge.model.WsjtxStatus;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.function.Consumer;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Listens on a UDP port for WSJT-X broadcast datagrams.
 *
 * <p>Runs on a dedicated background thread managed by a single-thread
 * {@link ExecutorService}.  Decoded messages are dispatched to registered
 * callback lambdas which are invoked on the listener thread.  The JavaFX UI
 * layer is responsible for marshalling those callbacks onto the FX thread via
 * {@code Platform.runLater()}.</p>
 *
 * <p>If WSJT-X is not running the listener simply blocks on the socket —
 * no errors are thrown.  Restart WSJT-X and the listener will automatically
 * start receiving packets.</p>
 */
public class WsjtxUdpListener {

    private static final Logger LOGGER = Logger.getLogger(WsjtxUdpListener.class.getName());

    /** Maximum expected UDP packet size from WSJT-X (bytes) */
    private static final int BUFFER_SIZE = 4096;

    // ── State ──────────────────────────────────────────────────────────────────

    private final int    port;
    private final String bindAddress;

    private volatile boolean running = false;
    private DatagramSocket socket;
    private final ExecutorService executor = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "wsjtx-udp-listener");
        t.setDaemon(true);
        return t;
    });

    // ── Protocol decoder (stateless, reused per listener instance) ────────────

    private final WsjtxProtocolDecoder decoder = new WsjtxProtocolDecoder();

    // ── Callbacks ─────────────────────────────────────────────────────────────

    /** Called when a new WsjtxDecode packet arrives (type 2) */
    private Consumer<WsjtxDecode> onDecode;

    /** Called when a Status packet arrives (type 1) */
    private Consumer<WsjtxStatus> onStatus;

    /** Called when a QSO Logged packet arrives (type 5) */
    private Consumer<WsjtxQsoLogged> onQsoLogged;

    /** Called with (connected=true, version) on Heartbeat; (false, null) on Close */
    private java.util.function.BiConsumer<Boolean, String> onConnectionChange;

    /** Called when the decode window is cleared (type 3) */
    private Runnable onClear;

    // ── Constructors ──────────────────────────────────────────────────────────

    public WsjtxUdpListener(int port, String bindAddress) {
        this.port        = port;
        this.bindAddress = bindAddress;
    }

    // ── Lifecycle ─────────────────────────────────────────────────────────────

    /**
     * Start the UDP listener on the configured port.
     * This method returns immediately; the listener runs on a background thread.
     */
    public void start() {
        if (running) {
            LOGGER.warning("UDP listener is already running");
            return;
        }
        running = true;
        executor.submit(this::listenLoop);
        LOGGER.info("WSJT-X UDP listener starting on " + bindAddress + ":" + port);
    }

    /**
     * Stop the UDP listener and close the socket.
     */
    public void stop() {
        running = false;
        if (socket != null && !socket.isClosed()) {
            socket.close();
        }
        executor.shutdown();
        LOGGER.info("WSJT-X UDP listener stopped");
    }

    // ── Internal listen loop ──────────────────────────────────────────────────

    private void listenLoop() {
        while (running) {
            try {
                openSocket();
                byte[] buffer = new byte[BUFFER_SIZE];
                DatagramPacket packet = new DatagramPacket(buffer, buffer.length);

                LOGGER.info("UDP listener ready, waiting for WSJT-X on port " + port);

                while (running) {
                    socket.receive(packet);
                    byte[] data = new byte[packet.getLength()];
                    System.arraycopy(packet.getData(), packet.getOffset(), data, 0, packet.getLength());
                    handlePacket(data);
                    // Reset packet length for next receive
                    packet.setLength(buffer.length);
                }

            } catch (Exception e) {
                if (running) {
                    LOGGER.log(Level.WARNING, "UDP listener error: " + e.getMessage() +
                               " — retrying in 5 s", e);
                    sleep(5000);
                }
            } finally {
                closeSocket();
            }
        }
    }

    private void openSocket() throws Exception {
        InetAddress addr = InetAddress.getByName(bindAddress);
        socket = new DatagramSocket(port, addr);
        socket.setSoTimeout(0); // block indefinitely
    }

    private void closeSocket() {
        if (socket != null && !socket.isClosed()) {
            socket.close();
        }
    }

    private void sleep(long ms) {
        try { Thread.sleep(ms); } catch (InterruptedException ie) { Thread.currentThread().interrupt(); }
    }

    // ── Packet dispatch ───────────────────────────────────────────────────────

    private void handlePacket(byte[] data) {
        WsjtxProtocolDecoder.DecodedMessage msg = decoder.decode(data);
        if (msg == null) return;

        switch (msg.messageType) {

            case WsjtxProtocolDecoder.TYPE_HEARTBEAT:
                LOGGER.fine("WSJT-X heartbeat v" + msg.version);
                if (onConnectionChange != null) {
                    onConnectionChange.accept(true, msg.version);
                }
                break;

            case WsjtxProtocolDecoder.TYPE_STATUS:
                if (msg.status != null && onStatus != null) {
                    onStatus.accept(msg.status);
                }
                break;

            case WsjtxProtocolDecoder.TYPE_DECODE:
                if (msg.decode != null && onDecode != null) {
                    onDecode.accept(msg.decode);
                }
                break;

            case WsjtxProtocolDecoder.TYPE_CLEAR:
                if (onClear != null) {
                    onClear.run();
                }
                break;

            case WsjtxProtocolDecoder.TYPE_QSO_LOGGED:
                if (msg.qsoLogged != null && onQsoLogged != null) {
                    onQsoLogged.accept(msg.qsoLogged);
                }
                break;

            case WsjtxProtocolDecoder.TYPE_CLOSE:
                LOGGER.info("WSJT-X sent Close message");
                if (onConnectionChange != null) {
                    onConnectionChange.accept(false, null);
                }
                break;

            default:
                LOGGER.fine("Ignored WSJT-X message type: " + msg.messageType);
        }
    }

    // ── Callback setters ──────────────────────────────────────────────────────

    public void setOnDecode(Consumer<WsjtxDecode> onDecode) {
        this.onDecode = onDecode;
    }

    public void setOnStatus(Consumer<WsjtxStatus> onStatus) {
        this.onStatus = onStatus;
    }

    public void setOnQsoLogged(Consumer<WsjtxQsoLogged> onQsoLogged) {
        this.onQsoLogged = onQsoLogged;
    }

    public void setOnConnectionChange(java.util.function.BiConsumer<Boolean, String> onConnectionChange) {
        this.onConnectionChange = onConnectionChange;
    }

    public void setOnClear(Runnable onClear) {
        this.onClear = onClear;
    }

    public boolean isRunning() { return running; }
    public int getPort() { return port; }
}
