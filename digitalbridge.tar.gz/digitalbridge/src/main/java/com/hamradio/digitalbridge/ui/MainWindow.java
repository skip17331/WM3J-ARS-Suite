package com.hamradio.digitalbridge.ui;

import com.google.gson.JsonObject;
import com.hamradio.digitalbridge.*;
import com.hamradio.digitalbridge.model.BandActivity;
import com.hamradio.digitalbridge.model.WsjtxDecode;
import com.hamradio.digitalbridge.model.WsjtxQsoLogged;
import com.hamradio.digitalbridge.model.WsjtxStatus;
import javafx.application.Platform;
import javafx.geometry.Insets;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
import javafx.stage.WindowEvent;

import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.Executors;
import java.util.concurrent.ScheduledExecutorService;
import java.util.concurrent.TimeUnit;
import java.util.logging.Logger;

/**
 * Primary application window.
 *
 * <pre>
 * ┌──────────────────────────────────────────────────────────────────┐
 * │  Toolbar: title + settings button                                │
 * ├─────────────────────────────────────────┬────────────────────────┤
 * │                                         │  WsjtxStatusPanel      │
 * │         DecodeTableView                 │  HubStatusPanel        │
 * │                                         │  BandActivityPanel     │
 * │                                         │                        │
 * └─────────────────────────────────────────┴────────────────────────┘
 * </pre>
 *
 * <p>All callbacks from background threads (UDP, WebSocket) are routed through
 * {@code Platform.runLater()} before touching any UI node.</p>
 */
public class MainWindow {

    private static final Logger LOGGER = Logger.getLogger(MainWindow.class.getName());

    // ── Core components ───────────────────────────────────────────────────────
    private final HubClient        hubClient;
    private final WsjtxUdpListener udpListener;
    private final MessagePublisher publisher;
    private final SpotEnricher     enricher  = SpotEnricher.getInstance();
    private final WorkedListManager worked   = WorkedListManager.getInstance();
    private final ConfigManager    cfg       = ConfigManager.getInstance();

    // ── UI components ─────────────────────────────────────────────────────────
    private final DecodeTableView   decodeTable;
    private final BandActivityPanel bandPanel;
    private final WsjtxStatusPanel  wsjtxPanel;
    private final HubStatusPanel    hubPanel;
    private final Stage             primaryStage;

    // ── State ─────────────────────────────────────────────────────────────────
    /** Last known WSJT-X operating frequency in Hz */
    private volatile long currentFrequency = 0;
    /** Last known WSJT-X mode */
    private volatile String currentMode = "FT8";
    /** Per-band activity accumulators */
    private final Map<String, BandActivity> bandActivity = new HashMap<>();

    /** Counter refresh task */
    private final ScheduledExecutorService timerService =
            Executors.newSingleThreadScheduledExecutor(r -> {
                Thread t = new Thread(r, "ui-counter-refresh");
                t.setDaemon(true);
                return t;
            });

    // ── Construction ──────────────────────────────────────────────────────────

    public MainWindow(HubClient hubClient,
                      WsjtxUdpListener udpListener,
                      MessagePublisher publisher,
                      Stage primaryStage) {
        this.hubClient    = hubClient;
        this.udpListener  = udpListener;
        this.publisher    = publisher;
        this.primaryStage = primaryStage;

        // Initialise band activity map
        for (String band : new String[]{"160m","80m","60m","40m","30m","20m","17m","15m","12m","10m","6m","2m"}) {
            bandActivity.put(band, new BandActivity(band));
        }

        // Build UI panels
        decodeTable = new DecodeTableView();
        decodeTable.setMaxHistory(cfg.getDecodeHistoryLength());
        decodeTable.setAutoScroll(cfg.isAutoScroll());

        bandPanel   = new BandActivityPanel();
        wsjtxPanel  = new WsjtxStatusPanel(cfg.getWsjtxUdpPort());
        hubPanel    = new HubStatusPanel(cfg.getHubAddress(), cfg.getHubPort());

        // Wire all callbacks
        wireUdpCallbacks();
        wireHubCallbacks();

        // Reconnect button
        hubPanel.setOnReconnect(() -> {
            LOGGER.info("Manual hub reconnect requested");
            hubClient.disconnect();
            hubClient.connect(cfg.getHubUri());
        });

        // Schedule counter refresh (messages sent/received) every 2 s
        timerService.scheduleAtFixedRate(this::refreshCounters, 2, 2, TimeUnit.SECONDS);
    }

    // ── Show ──────────────────────────────────────────────────────────────────

    public void show() {
        primaryStage.setTitle("Digital Bridge — WSJT-X Hub Bridge");
        primaryStage.setScene(buildScene());
        primaryStage.setWidth(1100);
        primaryStage.setHeight(680);
        primaryStage.setMinWidth(700);
        primaryStage.setMinHeight(400);

        // Graceful shutdown on window close
        primaryStage.addEventHandler(WindowEvent.WINDOW_CLOSE_REQUEST, e -> {
            LOGGER.info("Shutdown requested");
            timerService.shutdown();
            udpListener.stop();
            hubClient.disconnect();
            Platform.exit();
        });

        primaryStage.show();
    }

    // ── Scene construction ────────────────────────────────────────────────────

    private Scene buildScene() {
        // ── Toolbar ───────────────────────────────────────────────────────────
        Label titleLbl = new Label("Digital Bridge");
        titleLbl.setStyle("-fx-text-fill: #00d4ff; -fx-font-size: 16px; -fx-font-weight: bold;");

        Label subtitleLbl = new Label("WSJT-X ↔ Hub Bridge");
        subtitleLbl.setStyle("-fx-text-fill: #666688; -fx-font-size: 11px;");

        VBox titleBox = new VBox(1, titleLbl, subtitleLbl);

        // Filter controls in toolbar
        CheckBox autoScrollChk = new CheckBox("Auto-scroll");
        autoScrollChk.setSelected(cfg.isAutoScroll());
        autoScrollChk.setStyle("-fx-text-fill: #cccccc; -fx-font-size: 11px;");
        autoScrollChk.setOnAction(e -> {
            cfg.setAutoScroll(autoScrollChk.isSelected());
            decodeTable.setAutoScroll(autoScrollChk.isSelected());
        });

        CheckBox cqOnlyChk = new CheckBox("CQ only");
        cqOnlyChk.setSelected(cfg.isShowCQOnly());
        cqOnlyChk.setStyle("-fx-text-fill: #cccccc; -fx-font-size: 11px;");
        cqOnlyChk.setOnAction(e -> cfg.setShowCQOnly(cqOnlyChk.isSelected()));

        Button clearBtn = toolbarButton("Clear");
        clearBtn.setOnAction(e -> decodeTable.clear());

        Button settingsBtn = toolbarButton("⚙ Settings");
        settingsBtn.setOnAction(e -> {
            SettingsWindow sw = new SettingsWindow(primaryStage);
            sw.setOnSettingsChanged(() -> {
                LOGGER.info("Settings changed — applying");
                decodeTable.setMaxHistory(cfg.getDecodeHistoryLength());
                decodeTable.setAutoScroll(cfg.isAutoScroll());
                autoScrollChk.setSelected(cfg.isAutoScroll());
                cqOnlyChk.setSelected(cfg.isShowCQOnly());
                // Note: port changes require restart to take effect
            });
            sw.show();
        });

        Region spacer = new Region();
        HBox.setHgrow(spacer, Priority.ALWAYS);

        HBox toolbar = new HBox(12,
                titleBox, spacer,
                autoScrollChk, cqOnlyChk,
                clearBtn, settingsBtn);
        toolbar.setStyle("-fx-background-color: #0d0d22; -fx-padding: 8 12 8 12; " +
                         "-fx-border-color: #2a2a4a; -fx-border-width: 0 0 1 0;");
        toolbar.setAlignment(javafx.geometry.Pos.CENTER_LEFT);

        // ── Right sidebar ─────────────────────────────────────────────────────
        VBox sidebar = new VBox(0, wsjtxPanel, hubPanel, bandPanel);
        sidebar.setStyle("-fx-background-color: #111122; -fx-min-width: 175px; -fx-max-width: 175px;");
        VBox.setVgrow(bandPanel, Priority.ALWAYS);

        // ── Main layout ───────────────────────────────────────────────────────
        BorderPane center = new BorderPane();
        center.setCenter(decodeTable);
        center.setRight(sidebar);
        center.setStyle("-fx-background-color: #0d0d1a;");

        BorderPane root = new BorderPane();
        root.setTop(toolbar);
        root.setCenter(center);
        root.setStyle("-fx-background-color: #0d0d1a;");

        Scene scene = new Scene(root);
        scene.getStylesheets().add(
                getClass().getResource("/css/main.css") != null
                        ? getClass().getResource("/css/main.css").toExternalForm()
                        : "");
        return scene;
    }

    // ── UDP callback wiring ───────────────────────────────────────────────────

    private void wireUdpCallbacks() {

        // ── Heartbeat / Close ─────────────────────────────────────────────────
        udpListener.setOnConnectionChange((connected, version) ->
                Platform.runLater(() -> {
                    wsjtxPanel.setConnected(connected, version);
                    publisher.publishConnectionStatus(connected, version);
                    LOGGER.info("WSJT-X connection: " + connected + " v" + version);
                }));

        // ── Status ────────────────────────────────────────────────────────────
        udpListener.setOnStatus(status -> {
            currentFrequency = status.getDialFrequency();
            currentMode      = status.getMode();
            Platform.runLater(() -> {
                wsjtxPanel.setFrequency(status.getDialFrequency());
                wsjtxPanel.setMode(status.getMode());
                wsjtxPanel.setTransmitting(status.isTransmitting());
                wsjtxPanel.setDecoding(status.isDecoding());
            });
            publisher.publishStatus(status);
        });

        // ── Decode ────────────────────────────────────────────────────────────
        udpListener.setOnDecode(decode -> {
            // Attach current frequency and mode from last Status message
            decode.setFrequency(currentFrequency);
            decode.setMode(currentMode);
            decode.setBand(SpotEnricher.frequencyToBand(currentFrequency));

            // Extract callsign
            String callsign = CallsignParser.extractDxCallsign(decode.getMessage());
            decode.setCallsign(callsign);

            // Apply SNR and band filters
            if (decode.getSnr() < cfg.getMinimumSnr()) return;
            if (cfg.isShowCQOnly() && !decode.isCqCall()) return;
            String band = decode.getBand();
            boolean bandAllowed = Arrays.asList(cfg.getBandFilters()).contains(band);
            if (!bandAllowed) return;

            // Enrich with geo data
            if (callsign != null) {
                SpotEnricher.DxccInfo info = enricher.resolve(callsign);
                decode.setCountry(info.country);
                decode.setContinent(info.continent);
                decode.setDxcc(info.dxcc);
                decode.setLat(info.lat);
                decode.setLon(info.lon);
                decode.setBearing(enricher.bearing(info.lat, info.lon));
                double km = enricher.distanceKm(info.lat, info.lon);
                decode.setDistanceKm(km);
                decode.setDistanceMi(enricher.toMiles(km));
                decode.setLocalTimeAtSpot(enricher.localTimeAtSpot(info.utcOffset));
                decode.setWorkedStatus(worked.getWorkedStatus(callsign));
            }

            // Update band activity
            BandActivity ba = bandActivity.get(band);
            if (ba != null) {
                ba.incrementSpots();
                if (callsign != null) ba.updateTopDx(callsign, decode.getDistanceKm());
            }

            // Publish to hub
            if (callsign != null) {
                publisher.publishDecode(decode);
            }

            // Update UI on FX thread
            Platform.runLater(() -> {
                decodeTable.addDecode(decode);
                if (ba != null) bandPanel.update(ba);
            });
        });

        // ── QSO Logged ────────────────────────────────────────────────────────
        udpListener.setOnQsoLogged(qso -> {
            // Enrich QSO with country data
            if (qso.getDxCall() != null) {
                SpotEnricher.DxccInfo info = enricher.resolve(qso.getDxCall());
                qso.setCountry(info.country);
                qso.setContinent(info.continent);
                qso.setDxcc(info.dxcc);
                // Mark as worked locally
                worked.markWorked(qso.getDxCall());
            }
            publisher.publishQsoLogged(qso);
            LOGGER.info("QSO logged: " + qso.getDxCall());
        });

        // ── Clear ─────────────────────────────────────────────────────────────
        udpListener.setOnClear(() ->
                Platform.runLater(() -> {
                    decodeTable.clear();
                    bandActivity.values().forEach(BandActivity::reset);
                    bandPanel.reset();
                }));
    }

    // ── Hub callback wiring ───────────────────────────────────────────────────

    private void wireHubCallbacks() {

        // ── Connection state ──────────────────────────────────────────────────
        hubClient.setOnConnectionChange((connected, detail) ->
                Platform.runLater(() -> {
                    hubPanel.setConnected(connected, detail);
                    if (connected) {
                        // Send registration immediately on connect
                        publisher.sendAppConnected();
                    }
                }));

        // ── Incoming hub messages ─────────────────────────────────────────────
        hubClient.setOnMessage(json -> {
            String type = json.has("type") ? json.get("type").getAsString() : "";
            switch (type) {

                case "RIG_STATUS":
                    // Hub tells us about the rig — update our cached state
                    if (json.has("frequency")) {
                        currentFrequency = json.get("frequency").getAsLong();
                    }
                    if (json.has("mode")) {
                        currentMode = json.get("mode").getAsString();
                    }
                    break;

                case "STATION_LOCATION":
                    // Hub tells us our station lat/lon
                    if (json.has("lat") && json.has("lon")) {
                        double lat = json.get("lat").getAsDouble();
                        double lon = json.get("lon").getAsDouble();
                        enricher.setMyLocation(lat, lon);
                        LOGGER.info("Station location from hub: " + lat + ", " + lon);
                    }
                    break;

                case "WORKED_LIST":
                    // Hub sends initial worked callsign list
                    if (json.has("callsigns")) {
                        java.util.List<String> calls = new java.util.ArrayList<>();
                        json.getAsJsonArray("callsigns")
                            .forEach(el -> calls.add(el.getAsString()));
                        worked.setWorkedList(calls);
                        LOGGER.info("Received worked list from hub: " + calls.size() + " entries");
                    }
                    break;

                default:
                    LOGGER.fine("Unhandled hub message type: " + type);
            }
        });
    }

    // ── Counter refresh ───────────────────────────────────────────────────────

    /** Periodically update the hub message counters in the status panel. */
    private void refreshCounters() {
        long sent = hubClient.getMessagesSent();
        long recv = hubClient.getMessagesReceived();
        Platform.runLater(() -> {
            hubPanel.setSentCount(sent);
            hubPanel.setReceivedCount(recv);
        });
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private Button toolbarButton(String text) {
        Button btn = new Button(text);
        btn.setStyle("-fx-background-color: #2a2a5a; -fx-text-fill: #cccccc; " +
                     "-fx-font-size: 11px; -fx-cursor: hand; -fx-padding: 4 10 4 10;");
        return btn;
    }
}
