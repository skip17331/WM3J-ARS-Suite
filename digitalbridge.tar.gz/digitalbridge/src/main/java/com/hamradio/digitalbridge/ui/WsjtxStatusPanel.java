package com.hamradio.digitalbridge.ui;

import javafx.geometry.Insets;
import javafx.scene.control.Label;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.shape.Circle;

/**
 * Panel displaying the current WSJT-X connection and operating state.
 *
 * Shows:
 * <ul>
 *   <li>Connected / disconnected indicator (coloured circle)</li>
 *   <li>WSJT-X version when connected</li>
 *   <li>Current frequency and mode from Status messages</li>
 *   <li>TX / RX state</li>
 *   <li>Decoding indicator</li>
 *   <li>UDP port being listened on</li>
 * </ul>
 */
public class WsjtxStatusPanel extends VBox {

    private final Circle     indicator  = new Circle(6);
    private final Label      statusLbl  = fieldValue("Disconnected");
    private final Label      versionLbl = fieldValue("-");
    private final Label      freqLbl    = fieldValue("-");
    private final Label      modeLbl    = fieldValue("-");
    private final Label      txLbl      = fieldValue("RX");
    private final Label      decodeLbl  = fieldValue("-");
    private final Label      portLbl;

    public WsjtxStatusPanel(int udpPort) {
        portLbl = fieldValue(String.valueOf(udpPort));
        setSpacing(4);
        setPadding(new Insets(8));
        setStyle("-fx-background-color: #111122; -fx-border-color: #2a2a4a; -fx-border-width: 0 0 1 0;");

        Label header = new Label("WSJT-X");
        header.setStyle("-fx-text-fill: #00d4ff; -fx-font-size: 12px; -fx-font-weight: bold;");

        indicator.setFill(javafx.scene.paint.Color.web("#555555"));
        HBox statusRow = new HBox(6, indicator, statusLbl);
        statusRow.setStyle("-fx-alignment: center-left;");

        GridPane grid = new GridPane();
        grid.setHgap(8);
        grid.setVgap(2);
        grid.setPadding(new Insets(4, 0, 0, 0));

        int r = 0;
        grid.add(fieldKey("Status:"),  0, r); grid.add(statusRow,  1, r++);
        grid.add(fieldKey("Version:"), 0, r); grid.add(versionLbl, 1, r++);
        grid.add(fieldKey("Freq:"),    0, r); grid.add(freqLbl,    1, r++);
        grid.add(fieldKey("Mode:"),    0, r); grid.add(modeLbl,    1, r++);
        grid.add(fieldKey("TX/RX:"),   0, r); grid.add(txLbl,      1, r++);
        grid.add(fieldKey("Decode:"),  0, r); grid.add(decodeLbl,  1, r++);
        grid.add(fieldKey("UDP Port:"),0, r); grid.add(portLbl,    1, r++);

        getChildren().addAll(header, grid);
    }

    // ── Public update methods (call on FX thread) ─────────────────────────────

    public void setConnected(boolean connected, String version) {
        if (connected) {
            indicator.setFill(javafx.scene.paint.Color.web("#00dd00"));
            statusLbl.setText("Connected");
            versionLbl.setText(version != null ? version : "?");
        } else {
            indicator.setFill(javafx.scene.paint.Color.web("#555555"));
            statusLbl.setText("Disconnected");
            versionLbl.setText("-");
            freqLbl.setText("-");
            modeLbl.setText("-");
            txLbl.setText("RX");
            decodeLbl.setText("-");
        }
    }

    public void setFrequency(long hz) {
        if (hz > 0) {
            freqLbl.setText(String.format("%.3f MHz", hz / 1_000_000.0));
        } else {
            freqLbl.setText("-");
        }
    }

    public void setMode(String mode) {
        modeLbl.setText(mode != null ? mode : "-");
    }

    public void setTransmitting(boolean tx) {
        txLbl.setText(tx ? "TX" : "RX");
        txLbl.setStyle(tx
                ? "-fx-text-fill: #ff4444; -fx-font-weight: bold;"
                : "-fx-text-fill: #44ff44;");
    }

    public void setDecoding(boolean decoding) {
        decodeLbl.setText(decoding ? "Decoding…" : "Idle");
        decodeLbl.setStyle(decoding
                ? "-fx-text-fill: #ffdd00;"
                : "-fx-text-fill: #888888;");
    }

    // ── Helpers ───────────────────────────────────────────────────────────────

    private static Label fieldKey(String text) {
        Label l = new Label(text);
        l.setStyle("-fx-text-fill: #888888; -fx-font-size: 11px;");
        return l;
    }

    private static Label fieldValue(String text) {
        Label l = new Label(text);
        l.setStyle("-fx-text-fill: #cccccc; -fx-font-size: 11px;");
        return l;
    }
}
