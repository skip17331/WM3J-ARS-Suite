package com.hamradio.digitalbridge.model;

import java.time.Instant;

/**
 * Represents a QSO Logged message from WSJT-X (UDP message type 5).
 * Emitted when the user logs a contact in WSJT-X.
 */
public class WsjtxQsoLogged {

    /** UTC time the QSO was logged */
    private Instant timestamp;

    /** Callsign of the DX station */
    private String dxCall;

    /** DX grid locator */
    private String dxGrid;

    /** Dial frequency in Hz */
    private long dialFrequency;

    /** Operating mode */
    private String mode;

    /** RST sent */
    private String rstSent;

    /** RST received */
    private String rstReceived;

    /** TX power used */
    private String txPower;

    /** QSO comments or notes */
    private String comments;

    /** Name of the operator at the DX station */
    private String name;

    /** Time the QSO started (on-air) */
    private Instant timeOn;

    /** Time the QSO ended (off-air) */
    private Instant timeOff;

    /** Operator callsign */
    private String operatorCall;

    /** My exchange sent */
    private String myCall;

    /** My grid locator */
    private String myGrid;

    /** Exchange sent */
    private String exchangeSent;

    /** Exchange received */
    private String exchangeReceived;

    /** ADIF propagation mode */
    private String propagationMode;

    /** Derived ham band, e.g. "20m" */
    private String band;

    /** Country enrichment */
    private String country;

    /** Continent enrichment */
    private String continent;

    /** DXCC entity number */
    private int dxcc;

    // ── Constructors ──────────────────────────────────────────────────────────

    public WsjtxQsoLogged() {}

    // ── Getters and Setters ───────────────────────────────────────────────────

    public Instant getTimestamp() { return timestamp; }
    public void setTimestamp(Instant timestamp) { this.timestamp = timestamp; }

    public String getDxCall() { return dxCall; }
    public void setDxCall(String dxCall) { this.dxCall = dxCall; }

    public String getDxGrid() { return dxGrid; }
    public void setDxGrid(String dxGrid) { this.dxGrid = dxGrid; }

    public long getDialFrequency() { return dialFrequency; }
    public void setDialFrequency(long dialFrequency) { this.dialFrequency = dialFrequency; }

    public String getMode() { return mode; }
    public void setMode(String mode) { this.mode = mode; }

    public String getRstSent() { return rstSent; }
    public void setRstSent(String rstSent) { this.rstSent = rstSent; }

    public String getRstReceived() { return rstReceived; }
    public void setRstReceived(String rstReceived) { this.rstReceived = rstReceived; }

    public String getTxPower() { return txPower; }
    public void setTxPower(String txPower) { this.txPower = txPower; }

    public String getComments() { return comments; }
    public void setComments(String comments) { this.comments = comments; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public Instant getTimeOn() { return timeOn; }
    public void setTimeOn(Instant timeOn) { this.timeOn = timeOn; }

    public Instant getTimeOff() { return timeOff; }
    public void setTimeOff(Instant timeOff) { this.timeOff = timeOff; }

    public String getOperatorCall() { return operatorCall; }
    public void setOperatorCall(String operatorCall) { this.operatorCall = operatorCall; }

    public String getMyCall() { return myCall; }
    public void setMyCall(String myCall) { this.myCall = myCall; }

    public String getMyGrid() { return myGrid; }
    public void setMyGrid(String myGrid) { this.myGrid = myGrid; }

    public String getExchangeSent() { return exchangeSent; }
    public void setExchangeSent(String exchangeSent) { this.exchangeSent = exchangeSent; }

    public String getExchangeReceived() { return exchangeReceived; }
    public void setExchangeReceived(String exchangeReceived) { this.exchangeReceived = exchangeReceived; }

    public String getPropagationMode() { return propagationMode; }
    public void setPropagationMode(String propagationMode) { this.propagationMode = propagationMode; }

    public String getBand() { return band; }
    public void setBand(String band) { this.band = band; }

    public String getCountry() { return country; }
    public void setCountry(String country) { this.country = country; }

    public String getContinent() { return continent; }
    public void setContinent(String continent) { this.continent = continent; }

    public int getDxcc() { return dxcc; }
    public void setDxcc(int dxcc) { this.dxcc = dxcc; }

    @Override
    public String toString() {
        return "WsjtxQsoLogged{" +
               "dxCall='" + dxCall + '\'' +
               ", mode='" + mode + '\'' +
               ", band='" + band + '\'' +
               ", timestamp=" + timestamp +
               '}';
    }
}
