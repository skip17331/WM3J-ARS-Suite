package com.hamradio.digitalbridge.model;

/**
 * Represents a WSJT-X Status message (UDP message type 1).
 * Carries current rig frequency, mode, and TX/RX state.
 */
public class WsjtxStatus {

    /** RF dial frequency in Hz */
    private long dialFrequency;

    /** Operating mode string, e.g. "FT8", "JT65" */
    private String mode;

    /** DX call being worked or shown in WSJT-X */
    private String dxCall;

    /** Signal report, e.g. "-10" */
    private String report;

    /** TX DF offset in Hz */
    private int txDf;

    /** True while WSJT-X is transmitting */
    private boolean transmitting;

    /** True while WSJT-X is running the decoder */
    private boolean decoding;

    /** True if TX is enabled in WSJT-X */
    private boolean txEnabled;

    /** True if WSJT-X is in auto-sequence mode */
    private boolean txWatchdog;

    /** DX grid locator, if set */
    private String dxGrid;

    /** Derived ham band from dialFrequency, e.g. "20m" */
    private String band;

    // ── Constructors ──────────────────────────────────────────────────────────

    public WsjtxStatus() {}

    // ── Getters and Setters ───────────────────────────────────────────────────

    public long getDialFrequency() { return dialFrequency; }
    public void setDialFrequency(long dialFrequency) { this.dialFrequency = dialFrequency; }

    public String getMode() { return mode; }
    public void setMode(String mode) { this.mode = mode; }

    public String getDxCall() { return dxCall; }
    public void setDxCall(String dxCall) { this.dxCall = dxCall; }

    public String getReport() { return report; }
    public void setReport(String report) { this.report = report; }

    public int getTxDf() { return txDf; }
    public void setTxDf(int txDf) { this.txDf = txDf; }

    public boolean isTransmitting() { return transmitting; }
    public void setTransmitting(boolean transmitting) { this.transmitting = transmitting; }

    public boolean isDecoding() { return decoding; }
    public void setDecoding(boolean decoding) { this.decoding = decoding; }

    public boolean isTxEnabled() { return txEnabled; }
    public void setTxEnabled(boolean txEnabled) { this.txEnabled = txEnabled; }

    public boolean isTxWatchdog() { return txWatchdog; }
    public void setTxWatchdog(boolean txWatchdog) { this.txWatchdog = txWatchdog; }

    public String getDxGrid() { return dxGrid; }
    public void setDxGrid(String dxGrid) { this.dxGrid = dxGrid; }

    public String getBand() { return band; }
    public void setBand(String band) { this.band = band; }

    @Override
    public String toString() {
        return "WsjtxStatus{" +
               "freq=" + dialFrequency +
               ", mode='" + mode + '\'' +
               ", band='" + band + '\'' +
               ", tx=" + transmitting +
               ", decoding=" + decoding +
               '}';
    }
}
