package com.hamradio.digitalbridge.ui;

import com.hamradio.digitalbridge.ConfigManager;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.Window;

import java.util.Arrays;
import java.util.HashSet;
import java.util.Set;
import java.util.logging.Logger;

/**
 * Modal settings dialog.
 *
 * <p>Sections:</p>
 * <ul>
 *   <li><b>Hub</b> — WebSocket address and port</li>
 *   <li><b>WSJT-X</b> — UDP port and bind address</li>
 *   <li><b>Display</b> — history length, auto-scroll, SNR filter, band filters,
 *       CQ-only toggle</li>
 * </ul>
 *
 * <p>Changes take effect after clicking OK and a subsequent call to
 * {@link #setOnSettingsChanged(Runnable)}.</p>
 */
public class SettingsWindow {

    private static final Logger LOGGER = Logger.getLogger(SettingsWindow.class.getName());

    private static final String[] ALL_BANDS =
            {"160m","80m","60m","40m","30m","20m","17m","15m","12m","10m","6m","2m"};

    private final Stage stage;

    // ── Hub fields ────────────────────────────────────────────────────────────
    private final TextField hubAddressFld = new TextField();
    private final TextField hubPortFld    = new TextField();

    // ── WSJT-X fields ────────────────────────────────────────────────────────
    private final TextField wsjtxPortFld    = new TextField();
    private final TextField wsjtxBindFld    = new TextField();

    // ── Display fields ────────────────────────────────────────────────────────
    private final TextField  historyLenFld = new TextField();
    private final CheckBox   autoScrollChk = new CheckBox("Auto-scroll to newest decode");
    private final CheckBox   cqOnlyChk     = new CheckBox("Show CQ calls only");
    private final TextField  minSnrFld     = new TextField();
    private final java.util.Map<String, CheckBox> bandCheckBoxes = new java.util.LinkedHashMap<>();

    /** Called after settings are saved so the app can apply changes. */
    private Runnable onSettingsChanged;

    public SettingsWindow(Window owner) {
        stage = new Stage();
        stage.initModality(Modality.WINDOW_MODAL);
        stage.initOwner(owner);
        stage.setTitle("Digital Bridge — Settings");
        stage.setResizable(false);

        // ── Load current values ───────────────────────────────────────────────
        ConfigManager cfg = ConfigManager.getInstance();
        hubAddressFld.setText(cfg.getHubAddress());
        hubPortFld.setText(String.valueOf(cfg.getHubPort()));
        wsjtxPortFld.setText(String.valueOf(cfg.getWsjtxUdpPort()));
        wsjtxBindFld.setText(cfg.getWsjtxBindAddress());
        historyLenFld.setText(String.valueOf(cfg.getDecodeHistoryLength()));
        autoScrollChk.setSelected(cfg.isAutoScroll());
        cqOnlyChk.setSelected(cfg.isShowCQOnly());
        minSnrFld.setText(String.valueOf(cfg.getMinimumSnr()));

        Set<String> activeBands = new HashSet<>(Arrays.asList(cfg.getBandFilters()));
        for (String band : ALL_BANDS) {
            CheckBox cb = new CheckBox(band);
            cb.setSelected(activeBands.contains(band));
            cb.setStyle("-fx-text-fill: #cccccc;");
            bandCheckBoxes.put(band, cb);
        }

        // ── Build UI ──────────────────────────────────────────────────────────
        VBox root = new VBox(12,
                sectionBox("Hub Connection",
                        row("Address:", hubAddressFld),
                        row("Port:",    hubPortFld)),
                sectionBox("WSJT-X UDP",
                        row("UDP Port:",     wsjtxPortFld),
                        row("Bind Address:", wsjtxBindFld)),
                sectionBox("Display",
                        row("History Length:", historyLenFld),
                        row("Min SNR (dB):",   minSnrFld),
                        autoScrollChk,
                        cqOnlyChk,
                        bandFilterBox()));

        root.setPadding(new Insets(16));
        root.setStyle("-fx-background-color: #1a1a2e;");

        // ── Buttons ───────────────────────────────────────────────────────────
        Button okBtn     = styledButton("OK",     "#2a5a2a");
        Button cancelBtn = styledButton("Cancel", "#3a2a2a");

        okBtn.setOnAction(e -> {
            if (saveSettings()) {
                stage.close();
                if (onSettingsChanged != null) onSettingsChanged.run();
            }
        });
        cancelBtn.setOnAction(e -> stage.close());

        HBox buttonRow = new HBox(8, cancelBtn, okBtn);
        buttonRow.setAlignment(Pos.CENTER_RIGHT);
        buttonRow.setPadding(new Insets(8, 0, 0, 0));

        VBox outer = new VBox(0, new ScrollPane(root), buttonRow);
        outer.setPadding(new Insets(8));
        outer.setStyle("-fx-background-color: #1a1a2e;");

        ((ScrollPane) outer.getChildren().get(0)).setFitToWidth(true);
        ((ScrollPane) outer.getChildren().get(0)).setPrefViewportHeight(480);
        ((ScrollPane) outer.getChildren().get(0)).setStyle("-fx-background: #1a1a2e;");

        stage.setScene(new Scene(outer, 420, 580));
        stage.getScene().setFill(javafx.scene.paint.Color.web("#1a1a2e"));
    }

    // ── Public API ────────────────────────────────────────────────────────────

    public void show() {
        stage.show();
    }

    public void setOnSettingsChanged(Runnable cb) {
        this.onSettingsChanged = cb;
    }

    // ── Save logic ────────────────────────────────────────────────────────────

    /**
     * Validate and persist settings.
     *
     * @return true if all fields were valid and config was saved
     */
    private boolean saveSettings() {
        try {
            ConfigManager cfg = ConfigManager.getInstance();

            String address = hubAddressFld.getText().trim();
            int hubPort    = Integer.parseInt(hubPortFld.getText().trim());
            int udpPort    = Integer.parseInt(wsjtxPortFld.getText().trim());
            String bind    = wsjtxBindFld.getText().trim();
            int histLen    = Integer.parseInt(historyLenFld.getText().trim());
            int minSnr     = Integer.parseInt(minSnrFld.getText().trim());

            if (address.isEmpty() || bind.isEmpty()) throw new IllegalArgumentException("Address cannot be empty");
            if (hubPort < 1 || hubPort > 65535)      throw new IllegalArgumentException("Hub port out of range");
            if (udpPort < 1 || udpPort > 65535)      throw new IllegalArgumentException("UDP port out of range");
            if (histLen < 10 || histLen > 5000)      throw new IllegalArgumentException("History length must be 10–5000");

            cfg.setHubAddress(address);
            cfg.setHubPort(hubPort);
            cfg.setWsjtxUdpPort(udpPort);
            cfg.setWsjtxBindAddress(bind);
            cfg.setDecodeHistoryLength(histLen);
            cfg.setMinimumSnr(minSnr);
            cfg.setAutoScroll(autoScrollChk.isSelected());
            cfg.setShowCQOnly(cqOnlyChk.isSelected());

            String[] bands = bandCheckBoxes.entrySet().stream()
                    .filter(e -> e.getValue().isSelected())
                    .map(java.util.Map.Entry::getKey)
                    .toArray(String[]::new);
            cfg.setBandFilters(bands);

            cfg.save();
            LOGGER.info("Settings saved");
            return true;

        } catch (NumberFormatException e) {
            alert("Invalid number", "Please enter valid integers for port and length fields.");
            return false;
        } catch (IllegalArgumentException e) {
            alert("Validation error", e.getMessage());
            return false;
        }
    }

    // ── Layout helpers ────────────────────────────────────────────────────────

    private VBox sectionBox(String title, javafx.scene.Node... children) {
        Label header = new Label(title);
        header.setStyle("-fx-text-fill: #00d4ff; -fx-font-size: 12px; -fx-font-weight: bold;");
        VBox box = new VBox(6, header);
        box.getChildren().addAll(children);
        box.setStyle("-fx-background-color: #111130; -fx-padding: 10; -fx-border-color: #2a2a4a; -fx-border-width: 1;");
        return box;
    }

    private HBox row(String labelText, javafx.scene.Node control) {
        Label lbl = new Label(labelText);
        lbl.setMinWidth(120);
        lbl.setStyle("-fx-text-fill: #aaaaaa; -fx-font-size: 11px;");
        if (control instanceof TextField) {
            ((TextField) control).setStyle(
                    "-fx-background-color: #0d0d22; -fx-text-fill: #e0e0e0; " +
                    "-fx-border-color: #3a3a6a; -fx-font-size: 11px;");
            ((TextField) control).setPrefWidth(200);
        }
        HBox row = new HBox(8, lbl, control);
        row.setAlignment(Pos.CENTER_LEFT);
        return row;
    }

    private FlowPane bandFilterBox() {
        Label lbl = new Label("Active Bands:");
        lbl.setStyle("-fx-text-fill: #aaaaaa; -fx-font-size: 11px;");
        FlowPane fp = new FlowPane(6, 4);
        fp.getChildren().addAll(bandCheckBoxes.values());
        return fp;
    }

    private Button styledButton(String text, String bgColor) {
        Button btn = new Button(text);
        btn.setStyle("-fx-background-color: " + bgColor + "; -fx-text-fill: #cccccc; " +
                     "-fx-font-size: 12px; -fx-cursor: hand; -fx-padding: 5 14 5 14;");
        return btn;
    }

    private void alert(String title, String message) {
        Alert a = new Alert(Alert.AlertType.ERROR, message, ButtonType.OK);
        a.setTitle(title);
        a.setHeaderText(null);
        a.initOwner(stage);
        a.showAndWait();
    }
}
