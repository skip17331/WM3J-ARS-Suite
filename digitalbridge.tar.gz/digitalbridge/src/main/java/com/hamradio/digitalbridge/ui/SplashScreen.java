package com.hamradio.digitalbridge.ui;

import javafx.animation.FadeTransition;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.control.ProgressBar;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.util.Duration;

/**
 * Brief splash screen displayed while the application initialises.
 * Fades in, holds for a moment, then calls the supplied {@link Runnable}
 * completion callback.
 */
public class SplashScreen {

    private final Stage stage;

    public SplashScreen() {
        stage = new Stage(StageStyle.UNDECORATED);
        stage.setTitle("Digital Bridge");

        // ── Layout ───────────────────────────────────────────────────────────

        Label titleLabel = new Label("Digital Bridge");
        titleLabel.setStyle("-fx-font-size: 28px; -fx-font-weight: bold; -fx-text-fill: #00d4ff;");

        Label subtitleLabel = new Label("WSJT-X Hub Bridge v1.0.0");
        subtitleLabel.setStyle("-fx-font-size: 14px; -fx-text-fill: #aaaaaa;");

        Label vendorLabel = new Label("Ham Radio Suite");
        vendorLabel.setStyle("-fx-font-size: 11px; -fx-text-fill: #666666;");

        ProgressBar progressBar = new ProgressBar(-1); // indeterminate
        progressBar.setPrefWidth(300);
        progressBar.setStyle("-fx-accent: #00d4ff;");

        Label statusLabel = new Label("Initialising…");
        statusLabel.setStyle("-fx-font-size: 11px; -fx-text-fill: #888888;");

        VBox root = new VBox(12, titleLabel, subtitleLabel, vendorLabel, progressBar, statusLabel);
        root.setAlignment(Pos.CENTER);
        root.setPrefSize(380, 220);
        root.setStyle("-fx-background-color: #1a1a2e; -fx-border-color: #00d4ff; " +
                      "-fx-border-width: 1; -fx-padding: 30;");

        Scene scene = new Scene(root);
        scene.setFill(Color.TRANSPARENT);
        stage.setScene(scene);
        stage.centerOnScreen();
    }

    /**
     * Show the splash screen and invoke {@code onFinished} after the display
     * duration has elapsed.
     *
     * @param onFinished callback invoked on the JavaFX thread when splash closes
     */
    public void show(Runnable onFinished) {
        stage.show();

        // Fade in
        FadeTransition fadeIn = new FadeTransition(Duration.millis(400), stage.getScene().getRoot());
        fadeIn.setFromValue(0);
        fadeIn.setToValue(1);

        // After 2 s total, fade out and call back
        fadeIn.setOnFinished(e -> {
            javafx.animation.PauseTransition hold = new javafx.animation.PauseTransition(Duration.seconds(1.6));
            hold.setOnFinished(h -> {
                FadeTransition fadeOut = new FadeTransition(Duration.millis(300),
                                                            stage.getScene().getRoot());
                fadeOut.setFromValue(1);
                fadeOut.setToValue(0);
                fadeOut.setOnFinished(f -> {
                    stage.close();
                    if (onFinished != null) onFinished.run();
                });
                fadeOut.play();
            });
            hold.play();
        });

        fadeIn.play();
    }
}
