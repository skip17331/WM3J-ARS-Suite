package com.hamradio.digitalbridge;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.io.*;
import java.nio.file.*;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 * Manages loading and saving of the local application configuration stored in
 * {@code digitalbridge-config.json} in the current working directory.
 *
 * <p>Configuration values are exposed as simple typed getters.  The config
 * object is loaded once at startup; call {@link #save()} to persist changes.</p>
 */
public class ConfigManager {

    private static final Logger LOGGER = Logger.getLogger(ConfigManager.class.getName());
    private static final String CONFIG_FILE = "digitalbridge-config.json";

    // ── Internal config structure (mirrors the JSON schema) ───────────────────

    private String hubAddress = "localhost";
    private int    hubPort    = 8080;

    private int    wsjtxUdpPort    = 2237;
    private String wsjtxBindAddress = "0.0.0.0";

    private int     decodeHistoryLength = 200;
    private boolean autoScroll          = true;
    private boolean showCQOnly          = false;
    private int     minimumSnr          = -20;
    private String[] bandFilters        = {"160m","80m","40m","20m","15m","10m","6m"};

    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    // ── Singleton ─────────────────────────────────────────────────────────────

    private static ConfigManager instance;

    private ConfigManager() {}

    public static synchronized ConfigManager getInstance() {
        if (instance == null) {
            instance = new ConfigManager();
        }
        return instance;
    }

    // ── Load / Save ───────────────────────────────────────────────────────────

    /**
     * Load configuration from {@code digitalbridge-config.json}.
     * Falls back to defaults if the file is missing or unreadable.
     */
    public void load() {
        Path path = Paths.get(CONFIG_FILE);
        if (!Files.exists(path)) {
            LOGGER.info("Config file not found; using defaults and creating " + CONFIG_FILE);
            save();
            return;
        }
        try (Reader reader = Files.newBufferedReader(path)) {
            JsonObject root = JsonParser.parseReader(reader).getAsJsonObject();

            // Hub section
            if (root.has("hub")) {
                JsonObject hub = root.getAsJsonObject("hub");
                if (hub.has("address")) hubAddress = hub.get("address").getAsString();
                if (hub.has("port"))    hubPort    = hub.get("port").getAsInt();
            }

            // WSJT-X section
            if (root.has("wsjtx")) {
                JsonObject wx = root.getAsJsonObject("wsjtx");
                if (wx.has("udpPort"))     wsjtxUdpPort     = wx.get("udpPort").getAsInt();
                if (wx.has("bindAddress")) wsjtxBindAddress = wx.get("bindAddress").getAsString();
            }

            // Display section
            if (root.has("display")) {
                JsonObject disp = root.getAsJsonObject("display");
                if (disp.has("decodeHistoryLength")) decodeHistoryLength = disp.get("decodeHistoryLength").getAsInt();
                if (disp.has("autoScroll"))          autoScroll          = disp.get("autoScroll").getAsBoolean();
                if (disp.has("showCQOnly"))          showCQOnly          = disp.get("showCQOnly").getAsBoolean();
                if (disp.has("minimumSnr"))          minimumSnr          = disp.get("minimumSnr").getAsInt();
                if (disp.has("bandFilters")) {
                    bandFilters = gson.fromJson(disp.get("bandFilters"), String[].class);
                }
            }

            LOGGER.info("Configuration loaded from " + CONFIG_FILE);
        } catch (Exception e) {
            LOGGER.log(Level.WARNING, "Failed to read config; using defaults", e);
        }
    }

    /**
     * Persist the current configuration back to {@code digitalbridge-config.json}.
     */
    public void save() {
        try {
            JsonObject root = new JsonObject();

            JsonObject hub = new JsonObject();
            hub.addProperty("address", hubAddress);
            hub.addProperty("port",    hubPort);
            root.add("hub", hub);

            JsonObject wx = new JsonObject();
            wx.addProperty("udpPort",     wsjtxUdpPort);
            wx.addProperty("bindAddress", wsjtxBindAddress);
            root.add("wsjtx", wx);

            JsonObject disp = new JsonObject();
            disp.addProperty("decodeHistoryLength", decodeHistoryLength);
            disp.addProperty("autoScroll",          autoScroll);
            disp.addProperty("showCQOnly",          showCQOnly);
            disp.addProperty("minimumSnr",          minimumSnr);
            disp.add("bandFilters", gson.toJsonTree(bandFilters));
            root.add("display", disp);

            try (Writer writer = Files.newBufferedWriter(Paths.get(CONFIG_FILE))) {
                gson.toJson(root, writer);
            }
            LOGGER.info("Configuration saved to " + CONFIG_FILE);
        } catch (IOException e) {
            LOGGER.log(Level.WARNING, "Failed to save config", e);
        }
    }

    // ── Getters / Setters ─────────────────────────────────────────────────────

    public String getHubAddress() { return hubAddress; }
    public void setHubAddress(String hubAddress) { this.hubAddress = hubAddress; }

    public int getHubPort() { return hubPort; }
    public void setHubPort(int hubPort) { this.hubPort = hubPort; }

    public int getWsjtxUdpPort() { return wsjtxUdpPort; }
    public void setWsjtxUdpPort(int wsjtxUdpPort) { this.wsjtxUdpPort = wsjtxUdpPort; }

    public String getWsjtxBindAddress() { return wsjtxBindAddress; }
    public void setWsjtxBindAddress(String wsjtxBindAddress) { this.wsjtxBindAddress = wsjtxBindAddress; }

    public int getDecodeHistoryLength() { return decodeHistoryLength; }
    public void setDecodeHistoryLength(int decodeHistoryLength) { this.decodeHistoryLength = decodeHistoryLength; }

    public boolean isAutoScroll() { return autoScroll; }
    public void setAutoScroll(boolean autoScroll) { this.autoScroll = autoScroll; }

    public boolean isShowCQOnly() { return showCQOnly; }
    public void setShowCQOnly(boolean showCQOnly) { this.showCQOnly = showCQOnly; }

    public int getMinimumSnr() { return minimumSnr; }
    public void setMinimumSnr(int minimumSnr) { this.minimumSnr = minimumSnr; }

    public String[] getBandFilters() { return bandFilters; }
    public void setBandFilters(String[] bandFilters) { this.bandFilters = bandFilters; }

    /** Returns the full WebSocket URI for the hub, e.g. {@code ws://localhost:8080} */
    public String getHubUri() {
        return "ws://" + hubAddress + ":" + hubPort;
    }
}
