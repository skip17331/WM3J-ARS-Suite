package com.hamradio.digitalbridge.model;

/**
 * Aggregated activity summary for a single ham band.
 * Displayed in the BandActivityPanel side panel.
 */
public class BandActivity {

    /** Band name, e.g. "20m" */
    private String band;

    /** Number of unique callsigns decoded on this band in the current session */
    private int spotCount;

    /** Best DX callsign seen on this band (by distance, if known; else most recent) */
    private String topDxCall;

    /** Distance to the best DX station in kilometres */
    private double topDxDistanceKm;

    // ── Constructors ──────────────────────────────────────────────────────────

    public BandActivity(String band) {
        this.band = band;
        this.spotCount = 0;
        this.topDxCall = "-";
        this.topDxDistanceKm = 0;
    }

    // ── Getters / Setters ─────────────────────────────────────────────────────

    public String getBand() { return band; }

    public int getSpotCount() { return spotCount; }
    public void setSpotCount(int spotCount) { this.spotCount = spotCount; }

    public String getTopDxCall() { return topDxCall; }
    public void setTopDxCall(String topDxCall) { this.topDxCall = topDxCall; }

    public double getTopDxDistanceKm() { return topDxDistanceKm; }
    public void setTopDxDistanceKm(double topDxDistanceKm) { this.topDxDistanceKm = topDxDistanceKm; }

    /** Increment the spot counter by one. */
    public void incrementSpots() { this.spotCount++; }

    /** Update top-DX if the supplied station is farther away. */
    public void updateTopDx(String callsign, double distKm) {
        if (distKm > this.topDxDistanceKm) {
            this.topDxCall = callsign;
            this.topDxDistanceKm = distKm;
        }
        // If we have no top-DX yet just set it regardless of distance
        if ("-".equals(this.topDxCall) && callsign != null && !callsign.isEmpty()) {
            this.topDxCall = callsign;
        }
    }

    /** Reset counters (call at the start of a new decode period). */
    public void reset() {
        this.spotCount = 0;
        this.topDxCall = "-";
        this.topDxDistanceKm = 0;
    }

    @Override
    public String toString() {
        return "BandActivity{band='" + band + "', spots=" + spotCount + ", topDx='" + topDxCall + "'}";
    }
}
